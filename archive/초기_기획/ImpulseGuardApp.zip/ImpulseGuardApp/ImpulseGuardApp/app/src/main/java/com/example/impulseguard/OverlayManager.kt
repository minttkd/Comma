package com.example.impulseguard

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.widget.EditText
import android.widget.TextView

/**
 * 접근성 서비스가 감지한 결제 버튼 위에, 우리 판단 결과 카드를 시스템 오버레이로 띄운다.
 *
 * v2: 신호등 판단만 보여주고 바로 버튼을 주는 대신, (안전 등급이 아니면) AI와 최대 3라운드
 * 짧은 문답을 주고받은 뒤에야 최종 버튼(구매하기/그만두기)이 나타난다. 문답 진행 자체는
 * 호출부(PurchaseGuardService)가 관리하고, 이 클래스는 화면을 그리고 사용자 입력을
 * 콜백으로 돌려주는 역할만 한다.
 *
 * 정직하게 밝혀둘 점: 다른 앱 화면 위에 뜨는 시스템 오버레이 창(TYPE_APPLICATION_OVERLAY)에서
 * EditText가 키보드 포커스를 정상적으로 받는지는 기종/제조사/OS 버전마다 다르게 동작할 수 있는데,
 * 이 환경에는 실제 기기가 없어서 확인하지 못했다. 만약 실기기에서 키보드가 안 뜨거나 포커스가
 * 안 잡히면, WindowManager.LayoutParams의 flags에 FLAG_ALT_FOCUSABLE_IM 조정이 필요할 수 있다.
 */
class OverlayManager(private val context: Context) {

    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private var overlayView: View? = null
    private var messageView: TextView? = null
    private val baseMessage = StringBuilder()

    fun isShowing(): Boolean = overlayView != null

    /** 오버레이를 처음 띄운다. 신호등 판단 정보만 그려두고, 이어서 showQuestion()/showDecisionButtons()로 채운다. */
    fun show(judgment: BudgetEngine.Judgment) {
        if (overlayView != null) return // 이미 떠 있으면 중복으로 띄우지 않는다.

        val inflater = LayoutInflater.from(context)
        val view = inflater.inflate(R.layout.overlay_purchase_check, null)

        val dot = view.findViewById<View>(R.id.statusDot)
        val title = view.findViewById<TextView>(R.id.statusTitle)
        val message = view.findViewById<TextView>(R.id.statusMessage)
        val remaining = view.findViewById<TextView>(R.id.remainingText)
        messageView = message
        baseMessage.clear()
        baseMessage.append(judgment.message)

        val (color, label) = when (judgment.status) {
            "danger" -> Color.parseColor("#E0604B") to "위험해요"
            "warning" -> Color.parseColor("#E8A33D") to "주의하세요"
            else -> Color.parseColor("#1FA774") to "괜찮아요"
        }
        val dotDrawable = GradientDrawable()
        dotDrawable.shape = GradientDrawable.OVAL
        dotDrawable.setColor(color)
        dot.background = dotDrawable

        title.text = "지금 사도 될까요? — $label"
        message.text = judgment.message
        remaining.text = "지금 사면 남은 여유: ${"%,d".format(judgment.remainingAfter)}원"

        val overlayType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            overlayType,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            android.graphics.PixelFormat.TRANSLUCENT
        )
        params.gravity = Gravity.CENTER
        params.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE

        windowManager.addView(view, params)
        overlayView = view
    }

    /**
     * AiCoach가 백그라운드에서 만든 코칭 코멘트가 늦게 도착했을 때, 아직 오버레이가 떠 있으면
     * 기존 신호등 메시지 아래에 이어붙인다. 오버레이가 이미 닫혔으면 조용히 무시한다.
     */
    fun appendAiComment(comment: String) {
        val view = messageView ?: return
        baseMessage.append("\n\n").append(comment)
        view.text = baseMessage.toString()
    }

    /**
     * 문답 한 라운드를 화면에 띄운다. 사용자가 답을 입력하고 "답변 보내기"를 누르면
     * onAnswer로 답변 텍스트를 넘겨준다. 다음 라운드로 이어갈지, 최종 버튼으로 넘어갈지는
     * 호출부(PurchaseGuardService)가 onAnswer 안에서 결정한다.
     */
    fun showQuestion(round: Int, total: Int, question: String, onAnswer: (String) -> Unit) {
        val view = overlayView ?: return
        val chatSection = view.findViewById<View>(R.id.chatSection)
        val decisionSection = view.findViewById<View>(R.id.decisionSection)
        val progress = view.findViewById<TextView>(R.id.chatProgress)
        val questionView = view.findViewById<TextView>(R.id.chatQuestion)
        val input = view.findViewById<EditText>(R.id.chatAnswerInput)
        val send = view.findViewById<View>(R.id.btnChatSend)

        decisionSection.visibility = View.GONE
        chatSection.visibility = View.VISIBLE
        progress.text = "AI와 잠깐 얘기해볼까요? ($round/$total)"
        questionView.text = question
        input.text?.clear()

        send.setOnClickListener {
            val answer = input.text?.toString()?.trim().orEmpty()
            if (answer.isEmpty()) return@setOnClickListener
            onAnswer(answer)
        }
    }

    /**
     * 문답이 끝난 뒤(또는 안전 등급이라 문답 자체가 없을 때) 최종 버튼을 띄운다.
     * requireTyping이 true면(위험 등급) requiredPhrase를 정확히 입력해야만
     * "구매하기" 버튼이 눌리게 된다. "그만두기"는 항상 바로 누를 수 있다 — 숨기거나
     * 막아두는 게 아니라 시각적으로만 작고 튀지 않게 둔 것뿐이다.
     */
    fun showDecisionButtons(
        requireTyping: Boolean,
        requiredPhrase: String,
        onCancel: () -> Unit,
        onContinue: () -> Unit
    ) {
        val view = overlayView ?: return
        val chatSection = view.findViewById<View>(R.id.chatSection)
        val decisionSection = view.findViewById<View>(R.id.decisionSection)
        val confirmLabel = view.findViewById<TextView>(R.id.dangerConfirmLabel)
        val confirmInput = view.findViewById<EditText>(R.id.dangerConfirmInput)
        val btnCancel = view.findViewById<View>(R.id.btnCancel)
        val btnContinue = view.findViewById<View>(R.id.btnContinue)

        chatSection.visibility = View.GONE
        decisionSection.visibility = View.VISIBLE

        btnCancel.setOnClickListener {
            dismiss()
            onCancel()
        }

        if (requireTyping) {
            confirmLabel.visibility = View.VISIBLE
            confirmLabel.text = "정말 사시려면 \"$requiredPhrase\"라고 그대로 입력해주세요."
            confirmInput.visibility = View.VISIBLE
            confirmInput.text?.clear()
            btnContinue.isEnabled = false
            btnContinue.alpha = 0.4f
            confirmInput.addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    val matches = s?.toString() == requiredPhrase
                    btnContinue.isEnabled = matches
                    btnContinue.alpha = if (matches) 1f else 0.4f
                }
                override fun afterTextChanged(s: Editable?) {}
            })
        } else {
            confirmLabel.visibility = View.GONE
            confirmInput.visibility = View.GONE
            btnContinue.isEnabled = true
            btnContinue.alpha = 1f
        }

        btnContinue.setOnClickListener {
            if (!btnContinue.isEnabled) return@setOnClickListener
            dismiss()
            onContinue()
        }
    }

    fun dismiss() {
        overlayView?.let {
            windowManager.removeView(it)
            overlayView = null
            messageView = null
        }
    }
}
