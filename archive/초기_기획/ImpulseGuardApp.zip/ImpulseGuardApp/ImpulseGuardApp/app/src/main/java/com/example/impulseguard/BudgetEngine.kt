package com.example.impulseguard

/**
 * 예산 판단 핵심 로직.
 * Flask 프로토타입(app.py)의 summarize()/judge() 함수를 코틀린으로 그대로 옮긴 것으로,
 * "수입 - 고정지출 - 이미 쓴 금액 = 남은 여유" 계산과 신호등 판정 규칙이 동일합니다.
 */
object BudgetEngine {

    // 남은 여유가 수입의 이 비율 밑으로 떨어지면 "주의"로 표시한다.
    private const val WARNING_RATIO = 0.15

    data class Summary(
        val fixedTotal: Int,
        val spentTotal: Int,
        val remaining: Int
    )

    data class Judgment(
        val status: String,       // "safe" | "warning" | "danger"
        val message: String,
        val remainingBefore: Int,
        val remainingAfter: Int
    )

    fun summarize(budget: Budget): Summary {
        val fixedTotal = budget.fixedExpenses.sumOf { it.amount }
        val spentTotal = budget.purchases.sumOf { it.amount }
        val remaining = budget.income - fixedTotal - spentTotal
        return Summary(fixedTotal, spentTotal, remaining)
    }

    fun judge(remainingBefore: Int, amount: Int, income: Int): Judgment {
        val remainingAfter = remainingBefore - amount
        val buffer = (income * WARNING_RATIO).toInt()

        val (status, message) = when {
            remainingAfter < 0 -> "danger" to "이번 달 남은 여유를 넘어서는 지출이에요."
            remainingAfter < buffer -> "warning" to "살 수는 있지만, 이번 달 여유가 많이 줄어들어요."
            else -> "safe" to "이번 달 여유 안에서 괜찮은 소비예요."
        }

        return Judgment(status, message, remainingBefore, remainingAfter)
    }

    /** "충동구매 방지 실적" 대시보드에 쓰는 통계. AI 없이 항상 즉시 계산 가능한 규칙 기반 값이다. */
    data class Stats(
        val totalAttempts: Int,
        val preventedCount: Int,
        val confirmedCount: Int,
        val preventionRate: Int, // 0~100
        val savedAmount: Int,
        val periodLabel: String // "yyyy-MM"
    )

    /** [yearMonth]("yyyy-MM")에 해당하는 달의 방지/구매 실적을 집계한다. */
    fun computeStats(budget: Budget, yearMonth: String): Stats {
        val confirmedThisMonth = budget.purchases.filter { it.date.startsWith(yearMonth) }
        val preventedThisMonth = budget.preventedAttempts.filter { it.date.startsWith(yearMonth) }
        val total = confirmedThisMonth.size + preventedThisMonth.size
        val rate = if (total == 0) 0 else (preventedThisMonth.size * 100) / total
        val saved = preventedThisMonth.sumOf { it.amount }
        return Stats(
            totalAttempts = total,
            preventedCount = preventedThisMonth.size,
            confirmedCount = confirmedThisMonth.size,
            preventionRate = rate,
            savedAmount = saved,
            periodLabel = yearMonth
        )
    }
}
