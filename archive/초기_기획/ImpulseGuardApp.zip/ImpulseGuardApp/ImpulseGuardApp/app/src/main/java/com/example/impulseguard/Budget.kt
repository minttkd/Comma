package com.example.impulseguard

data class FixedExpense(
    val name: String,
    val amount: Int,
    val source: String = "manual" // "manual" | "linked"
)

data class Purchase(
    val name: String,
    val amount: Int,
    val date: String
)

/** 계좌·카드 연동을 시뮬레이션한 가상의 원시 거래내역 한 건 (아직 고정/변동 분류 전). */
data class Transaction(
    val name: String,
    val amount: Int,
    val date: String
)

/**
 * "그만두기"로 실제로 막아낸 충동구매 한 건. 판단 카드가 뜬 뒤 사용자가 포기를 선택했을 때만
 * 기록되고(앱 안 수동 확인, 다른 앱 감지 오버레이 둘 다 여기 쌓인다), 방지 실적 대시보드와
 * AI 월간 회고의 재료로 쓰인다.
 */
data class PreventedAttempt(
    val name: String,
    val amount: Int,
    val date: String, // yyyy-MM-dd
    val status: String // "safe" | "warning" | "danger" — 판단 당시 신호등 등급
)

data class Budget(
    val income: Int = 0,
    val fixedExpenses: List<FixedExpense> = emptyList(),
    val purchases: List<Purchase> = emptyList(),
    val preventedAttempts: List<PreventedAttempt> = emptyList()
)
