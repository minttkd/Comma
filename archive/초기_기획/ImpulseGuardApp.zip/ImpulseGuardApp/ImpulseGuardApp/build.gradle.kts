// 최상위 빌드 설정. 실제 플러그인 버전 적용은 app/build.gradle.kts에서 이뤄집니다.
plugins {
    id("com.android.application") version "8.5.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.24" apply false
}
