package com.example.impulseguard

import android.os.Handler
import android.os.Looper
import android.util.Log
import org.json.JSONArray
import org.json.JSONObject
import java.net.URL
import javax.net.ssl.HttpsURLConnection

/**
 * "전문가 대체" 파트 — 재정 상담사가 사람마다 다르게 해주는 조언을,
 * 정해진 3단계 고정 문구 대신 AI(LLM)가 매번 다른 맥락으로 만들어주는 부분.
 *
 * BudgetEngine.judge()가 정한 신호등 색(safe/warning/danger)은 그대로 믿고 절대 바꾸지 않는다 —
 * AI는 "이미 나온 판단에 맞는 한두 문장의 코멘트"만 만든다. 그래서 만약 이 API 호출이
 * 실패해도(네트워크 없음, API 키 미입력, 요금 문제 등) 신호등 판단 자체는 항상 정상 동작한다.
 *
 * 정직하게 밝혀두는 한계: 이 코드는 실제 Anthropic API 키로 호출해서 응답을 받는 것까지는
 * 이 환경(샌드박스)에서 확인하지 못했다 — 이 환경에는 api.anthropic.com으로 나가는 네트워크가
 * 없고, 애초에 안드로이드 빌드 자체가 안 되는 환경이기 때문이다(README 참고). API 요청/응답
 * 형식은 2026년 9월 기준 공식 문서를 확인해서 맞췄지만, 본인의 API 키로 실제 기기에서 한 번
 * 테스트해보고 모델명이나 요금이 안 맞으면 아래 MODEL 상수만 바꾸면 된다.
 */
object AiCoach {

    private const val TAG = "AiCoach"
    private const val ENDPOINT = "https://api.anthropic.com/v1/messages"

    // 2026년 9월 기준 공식 문서상의 모델명. 값이 바뀌었거나 계정에서 막히면
    // https://platform.claude.com/docs/en/about-claude/models/overview 에서 최신 이름으로 교체.
    private const val MODEL = "claude-haiku-4-5-20251001"
    private const val ANTHROPIC_VERSION = "2023-06-01"
    private const val MAX_TOKENS = 200
    private const val TIMEOUT_MS = 10_000

    private val mainHandler = Handler(Looper.getMainLooper())

    /**
     * 백그라운드 스레드에서 AI 코멘트를 생성해서 콜백으로 돌려준다.
     * 콜백은 항상 메인 스레드에서 호출된다 (WebView/오버레이 UI 갱신에 바로 써도 안전).
     * 실패 시 콜백에 null을 넘긴다 — 호출부는 이 경우 그냥 아무것도 추가로 보여주지 않으면 된다.
     */
    fun generateComment(
        apiKey: String?,
        budget: Budget,
        summary: BudgetEngine.Summary,
        judgment: BudgetEngine.Judgment,
        itemName: String,
        amount: Int,
        onResult: (String?) -> Unit
    ) {
        if (apiKey.isNullOrBlank()) {
            // API 키를 아직 설정 안 한 사용자에게는 조용히 건너뛴다 (규칙 기반 메시지만 보여줌).
            return
        }

        Thread {
            val comment = try {
                callApi(apiKey, buildPrompt(budget, summary, judgment, itemName, amount))
            } catch (e: Exception) {
                Log.w(TAG, "AI 코멘트 생성 실패 (규칙 기반 판단은 영향 없음): ${e.message}")
                null
            }
            mainHandler.post { onResult(comment) }
        }.start()
    }

    data class ClassifiedExpense(val name: String, val amount: Int)

    /**
     * "Input 단계 축소" 파트 — 사람이 고정지출을 하나하나 직접 입력하는 대신,
     * (가상) 거래내역 리스트를 AI에게 보여주고 "매달 반복되는 고정지출로 보이는 것"만
     * 골라내게 한다. 이름이 몇 번 반복되는지, 금액이 매번 같은지 같은 패턴을 AI가 판단한다.
     * 실패하거나 API 키가 없으면 null을 돌려주고, 호출부(BudgetBridge)가 예전처럼
     * 하드코딩된 구독 목록으로 대체한다 — 여기서도 핵심 기능이 AI 하나에 의존하지 않는다.
     */
    fun classifyFixedExpenses(
        apiKey: String?,
        transactions: List<Transaction>,
        onResult: (List<ClassifiedExpense>?) -> Unit
    ) {
        if (apiKey.isNullOrBlank()) {
            onResult(null)
            return
        }

        Thread {
            val result = try {
                val text = callApi(apiKey, buildClassifyPrompt(transactions))
                parseClassifyResponse(text)
            } catch (e: Exception) {
                Log.w(TAG, "고정지출 분류 실패 (하드코딩 목록으로 대체됨): ${e.message}")
                null
            }
            mainHandler.post { onResult(result) }
        }.start()
    }

    private fun buildClassifyPrompt(transactions: List<Transaction>): String {
        val lines = transactions.joinToString("\n") { "- ${it.name} / ${"%,d".format(it.amount)}원 / ${it.date}" }
        return """
            아래는 어떤 사람의 최근 2개월 카드 거래내역입니다. 이 중에서 매달 반복되는
            "고정지출"(구독료, 통신요금, 헬스장 등 정기결제)로 보이는 항목만 골라주세요.
            한 번만 나오는 변동지출(카페, 배달, 쇼핑 등 일회성 소비)은 절대 포함하지 마세요.
            같은 이름이 여러 번 나오면 하나로 합쳐서 가장 최근 금액만 남기세요.

            다른 설명이나 인사말 없이, 아래 형식의 JSON 배열만 답하세요:
            [{"name": "항목 이름", "amount": 정수 금액}, ...]
            고정지출로 볼 만한 항목이 하나도 없으면 빈 배열 []만 답하세요.

            [거래내역]
            $lines
        """.trimIndent()
    }

    private fun parseClassifyResponse(text: String?): List<ClassifiedExpense>? {
        if (text.isNullOrBlank()) return null
        // 모델이 지시를 따르지 않고 ```json ... ``` 코드블록으로 감싸서 답하는 경우를 대비해
        // 첫 '['부터 마지막 ']'까지만 잘라내서 파싱한다.
        val start = text.indexOf('[')
        val end = text.lastIndexOf(']')
        if (start == -1 || end == -1 || end < start) return null

        val arr = JSONArray(text.substring(start, end + 1))
        val items = mutableListOf<ClassifiedExpense>()
        for (i in 0 until arr.length()) {
            val obj = arr.getJSONObject(i)
            val name = obj.optString("name").trim()
            val amount = obj.optInt("amount", 0)
            if (name.isNotBlank() && amount > 0) items.add(ClassifiedExpense(name, amount))
        }
        return items
    }

    private fun buildPrompt(
        budget: Budget,
        summary: BudgetEngine.Summary,
        judgment: BudgetEngine.Judgment,
        itemName: String,
        amount: Int
    ): String {
        val recentPurchases = budget.purchases.takeLast(8)
        val historyLines = if (recentPurchases.isEmpty()) {
            "(과거 구매 기록 없음)"
        } else {
            recentPurchases.joinToString("\n") { "- ${it.name} / ${"%,d".format(it.amount)}원 / ${it.date}" }
        }

        val statusKorean = when (judgment.status) {
            "danger" -> "위험 (여유를 넘어섬)"
            "warning" -> "주의 (여유가 많이 줄어듦)"
            else -> "안전 (여유 안에서 괜찮음)"
        }

        return """
            당신은 다정하지만 솔직한 개인 재정 코치입니다. 사용자가 지금 아래 항목을 구매할지 고민 중입니다.
            신호등 판단(안전/주의/위험)은 이미 정해져 있으니 그 판단을 절대 바꾸거나 다시 내리지 마세요.
            그 판단에 맞는 톤으로, 과거 구매 기록에 비슷하거나 겹치는 게 있으면 자연스럽게 짚어주면서,
            한국어 존댓말로 2~3문장짜리 짧은 조언만 답하세요. 다른 설명이나 인사말 없이 조언 본문만 답하세요.

            [이번 달 요약]
            수입: ${"%,d".format(budget.income)}원
            고정지출 합계: ${"%,d".format(summary.fixedTotal)}원
            이미 쓴 금액: ${"%,d".format(summary.spentTotal)}원
            이번 소비 전 남은 여유: ${"%,d".format(judgment.remainingBefore)}원

            [신호등 판단 결과] $statusKorean

            [이번에 사려는 것]
            이름: $itemName
            금액: ${"%,d".format(amount)}원

            [최근 구매 기록 (최대 8건)]
            $historyLines

            조언:
        """.trimIndent()
    }

    /**
     * "문답형 마찰" 파트 — 판단 카드가 뜬 뒤 바로 버튼을 주는 대신, 왜 사려고 하는지 같은
     * 짧은 질문을 AI가 사용자의 이전 답변에 맞춰 이어서 던지게 한다(최대 3라운드).
     * 정보 전달이 아니라 "잠깐 멈춰서 스스로 생각해보게" 만드는 게 목적이라, 질문 하나만
     * 딱 돌려주도록 프롬프트를 제한했다. 실패하거나 키가 없으면 null을 주고, 호출부
     * (PurchaseGuardService)가 하드코딩된 질문 목록으로 대체한다 — 여기서도 AI가 없다고
     * 문답 자체(마찰 장치)가 사라지지는 않는다.
     */
    fun generateFollowupQuestion(
        apiKey: String?,
        budget: Budget,
        judgment: BudgetEngine.Judgment,
        itemName: String,
        amount: Int,
        history: List<Pair<String, String>>,
        onResult: (String?) -> Unit
    ) {
        if (apiKey.isNullOrBlank()) {
            onResult(null)
            return
        }

        Thread {
            val question = try {
                callApi(apiKey, buildFollowupPrompt(judgment, itemName, amount, history))
            } catch (e: Exception) {
                Log.w(TAG, "AI 후속 질문 생성 실패 (하드코딩 질문으로 대체됨): ${e.message}")
                null
            }
            mainHandler.post { onResult(question) }
        }.start()
    }

    private fun buildFollowupPrompt(
        judgment: BudgetEngine.Judgment,
        itemName: String,
        amount: Int,
        history: List<Pair<String, String>>
    ): String {
        val historyLines = if (history.isEmpty()) {
            "(아직 질문한 적 없음 — 이번이 첫 질문)"
        } else {
            history.mapIndexed { i, (q, a) -> "Q${i + 1}: $q\nA${i + 1}: $a" }.joinToString("\n")
        }
        return """
            당신은 충동구매를 막으려는 다정한 재정 코치입니다. 사용자가 "$itemName"(${"%,d".format(amount)}원)을
            사려고 하고, 판단 결과는 "${judgment.status}"입니다. 훈계하거나 판단하지 말고, 사용자가 스스로
            다시 한번 생각해보게 만드는 짧고 자연스러운 질문을 딱 하나만 한국어 존댓말로 던지세요
            (구매 이유, 대안이 있는지, 나중에 후회하지 않을지 등을 가볍게 짚는 질문이면 좋습니다).
            지금까지 나눈 질문/답변과 겹치지 않는 새로운 질문이어야 합니다.
            질문 문장 하나만 답하고 다른 설명이나 인사말은 절대 붙이지 마세요.

            [지금까지의 대화]
            $historyLines

            다음 질문:
        """.trimIndent()
    }

    /**
     * "방지 실적 회고" 파트 — 이번 달 방지/구매 기록과 통계를 보고 AI가 격려와 구체적인
     * 패턴을 짚어주는 짧은 회고를 만든다. 실패하거나 키가 없으면 null을 주고, 호출부
     * (BudgetBridge)가 통계 숫자만으로 만든 규칙 기반 문장으로 대체한다 — 그래서 회고
     * 기능 자체(숫자 요약)는 AI 없이도 항상 나오고, AI는 거기에 "왜 잘했는지/아쉬웠는지"
     * 같은 정성적인 해석만 더하는 역할이다.
     */
    fun generateMonthlyReview(
        apiKey: String?,
        budget: Budget,
        stats: BudgetEngine.Stats,
        onResult: (String?) -> Unit
    ) {
        if (apiKey.isNullOrBlank()) {
            onResult(null)
            return
        }

        Thread {
            val review = try {
                callApi(apiKey, buildReviewPrompt(budget, stats))
            } catch (e: Exception) {
                Log.w(TAG, "AI 월간 회고 생성 실패 (규칙 기반 요약으로 대체됨): ${e.message}")
                null
            }
            mainHandler.post { onResult(review) }
        }.start()
    }

    private fun buildReviewPrompt(budget: Budget, stats: BudgetEngine.Stats): String {
        val preventedLines = budget.preventedAttempts
            .filter { it.date.startsWith(stats.periodLabel) }
            .takeLast(10)
            .joinToString("\n") { "- ${it.name} / ${"%,d".format(it.amount)}원 / 판단: ${it.status}" }
        val confirmedLines = budget.purchases
            .filter { it.date.startsWith(stats.periodLabel) }
            .takeLast(10)
            .joinToString("\n") { "- ${it.name} / ${"%,d".format(it.amount)}원" }

        return """
            당신은 다정하지만 솔직한 개인 재정 코치입니다. 아래는 사용자의 ${stats.periodLabel} 충동구매
            판단/방지 기록입니다. 이번 달 총 ${stats.totalAttempts}번의 판단 중 ${stats.preventedCount}번을
            참아냈고(방지율 ${stats.preventionRate}%), 약 ${"%,d".format(stats.savedAmount)}원을 지켰습니다.
            이 데이터를 보고, 잘한 점을 구체적으로 격려하면서 반복되는 패턴(자주 참은 종류,
            아쉽게 못 참은 부분 등)이 있으면 자연스럽게 짚어주는 3~4문장짜리 한국어 존댓말
            회고를 작성하세요. 다른 설명이나 인사말 없이 회고 본문만 답하세요.

            [이번 달 참아낸 기록]
            ${preventedLines.ifBlank { "(없음)" }}

            [이번 달 실제로 산 기록]
            ${confirmedLines.ifBlank { "(없음)" }}

            회고:
        """.trimIndent()
    }

    private fun callApi(apiKey: String, prompt: String): String? {
        val url = URL(ENDPOINT)
        val conn = url.openConnection() as HttpsURLConnection
        conn.requestMethod = "POST"
        conn.connectTimeout = TIMEOUT_MS
        conn.readTimeout = TIMEOUT_MS
        conn.doOutput = true
        conn.setRequestProperty("x-api-key", apiKey)
        conn.setRequestProperty("anthropic-version", ANTHROPIC_VERSION)
        conn.setRequestProperty("content-type", "application/json")

        val messages = JSONArray().put(
            JSONObject().apply {
                put("role", "user")
                put("content", prompt)
            }
        )
        val body = JSONObject().apply {
            put("model", MODEL)
            put("max_tokens", MAX_TOKENS)
            put("messages", messages)
        }

        conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }

        val code = conn.responseCode
        val stream = if (code in 200..299) conn.inputStream else conn.errorStream
        val responseText = stream?.bufferedReader()?.use { it.readText() } ?: ""

        if (code !in 200..299) {
            Log.w(TAG, "AI API 호출 실패 (HTTP $code): $responseText")
            return null
        }

        val json = JSONObject(responseText)
        val contentArr = json.optJSONArray("content") ?: return null
        val sb = StringBuilder()
        for (i in 0 until contentArr.length()) {
            val block = contentArr.getJSONObject(i)
            if (block.optString("type") == "text") {
                sb.append(block.optString("text"))
            }
        }
        val text = sb.toString().trim()
        return text.ifBlank { null }
    }

    /**
     * "계좌내역 AI 자동판단" 파트 — IncomeAnalyzer(규칙 기반 클러스터링)가 이미 내린 판정
     * (정기소득/비정기/데이터부족)은 여기서 절대 바꾸지 않는다. AI는 그 판정을 사용자에게
     * "매달 25일에 250만원이 들어오는데, 이걸 급여로 볼까요?"처럼 자연스러운 확인 질문
     * 문장으로 바꿔주는 역할만 한다. 실패하거나 키가 없으면 null을 주고, 호출부
     * (BudgetBridge)가 IncomeAnalyzer.Result.reason을 그대로 사용자에게 보여준다 —
     * 그래서 "AI 제안 + 사용자 확인" 흐름 자체는 AI 호출 성공 여부와 무관하게 항상 동작한다.
     */
    fun explainIncomeResult(
        apiKey: String?,
        result: IncomeAnalyzer.Result,
        onResult: (String?) -> Unit
    ) {
        if (apiKey.isNullOrBlank()) {
            onResult(null)
            return
        }

        Thread {
            val explanation = try {
                callApi(apiKey, buildIncomeExplainPrompt(result))
            } catch (e: Exception) {
                Log.w(TAG, "소득패턴 설명 생성 실패 (규칙 기반 문구로 대체됨): ${e.message}")
                null
            }
            mainHandler.post { onResult(explanation) }
        }.start()
    }

    private fun buildIncomeExplainPrompt(result: IncomeAnalyzer.Result): String {
        val statusKorean = when (result.status) {
            IncomeAnalyzer.Status.REGULAR -> "정기소득 패턴 감지됨"
            IncomeAnalyzer.Status.IRREGULAR -> "불규칙한(비정기) 입금 패턴"
            IncomeAnalyzer.Status.INSUFFICIENT_DATA -> "판단하기엔 관측 기간 부족"
        }
        return """
            당신은 가계 앱의 계좌 자동 분석 결과를 사용자에게 설명해주는 안내 도우미입니다.
            아래는 규칙 기반 알고리즘이 이미 확정한 판정 결과입니다 — 이 판정을 절대 바꾸거나
            의심하지 말고, 그대로 사용자에게 확인받기 위한 한국어 존댓말 1~2문장만 작성하세요.
            정기소득으로 감지된 경우엔 "맞으면 확인, 아니면 수정해달라"는 취지를 담고,
            비정기/데이터부족인 경우엔 왜 그렇게 판단했는지만 담백하게 설명하세요.
            다른 설명이나 인사말 없이 문장만 답하세요.

            [판정] $statusKorean
            [세부 근거] ${result.reason}
            [월 추정 금액] ${result.monthlyAmount?.let { "%,d원".format(it) } ?: "해당 없음"}
            [추정 입금일] ${result.payDay?.let { "매월 ${it}일" } ?: "해당 없음"}

            확인 문장:
        """.trimIndent()
    }
}
