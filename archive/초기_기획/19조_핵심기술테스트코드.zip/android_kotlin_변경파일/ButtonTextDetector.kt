package com.example.impulseguard

/**
 * "버튼 텍스트 감지" 핵심 로직만 따로 뺀 순수 코틀린(안드로이드 의존성 없음) 객체.
 *
 * 원래 이 정규식들은 PurchaseGuardService(AccessibilityService) 안에 직접 박혀 있었는데,
 * AccessibilityService는 실기기/에뮬레이터 없이는 단위 테스트가 불가능하다. 그래서 "화면에서
 * 모은 텍스트 목록 -> 구매 버튼 여부 + 금액" 판단 부분만 이 객체로 분리해서, 실기기 없이도
 * 로직 자체(정규식이 실제 배달앱 문구를 얼마나 잘 잡아내는지)를 테스트할 수 있게 했다.
 * PurchaseGuardService는 이 객체를 그대로 호출만 한다 — 판단 로직은 한 곳에만 존재한다.
 */
object ButtonTextDetector {

    // "00,000원"처럼 콤마가 있는 금액과 "9000원"처럼 콤마 없는 금액을 모두 잡는다.
    private val amountPattern = Regex("""[\d,]{4,}\s*원""")

    // 배달의민족/요기요/쿠팡이츠 등에서 공통적으로 쓰는 "결제 확정" 버튼 문구들.
    // "담기"/"장바구니"처럼 아직 결제 직전이 아닌 버튼은 의도적으로 제외한다.
    private val keywordPattern = Regex("구매하기|결제하기|주문하기|바로\\s*구매|바로\\s*결제|구매확정|결제확정")

    data class Detection(val amount: Int, val matchedKeyword: String)

    /**
     * 화면에서 모은 텍스트 노드들(버튼 라벨, contentDescription 등)을 받아
     * 구매 버튼 + 금액이 함께 감지되면 [Detection]을, 아니면 null을 돌려준다.
     *
     * 금액을 못 찾으면 판단 자체가 불가능하므로 null을 돌려준다 — "버튼은 눌렸는데
     * 얼마인지 모른 채로 예산 판단을 내리는" 상황을 만들지 않기 위함이다.
     */
    fun detect(texts: List<String>): Detection? {
        val joined = texts.joinToString(" ")

        val keywordMatch = keywordPattern.find(joined) ?: return null
        val amountMatch = amountPattern.find(joined) ?: return null

        val amount = amountMatch.value
            .replace(",", "")
            .replace("원", "")
            .trim()
            .toIntOrNull() ?: return null

        return Detection(amount = amount, matchedKeyword = keywordMatch.value)
    }
}
