package com.example.impulseguard

/**
 * "계좌내역 AI 자동판단" 핵심 로직 — 자기보고(사용자가 직접 월급을 입력)를 없애기 위해,
 * 최근 2~3개월치 입금 내역(계좌 연동 mock)을 보고 정기소득자인지 규칙 기반으로 먼저
 * 판단한다. 실제 서비스에서는 이 결과 + 원본 거래내역을 AI(Anthropic API)에게 보여줘서
 * "매달 OO일에 OO원이 들어와요, 급여로 보이는데 맞나요?" 같은 자연어 확인 문구를
 * 만들게 하고(AiCoach.explainIncomePattern 참고), 최종 확정은 항상 사용자가 누른다 —
 * AI가 자동으로 완전히 결정해버리지 않는다("AI 제안 + 사용자 확인" 원칙).
 *
 * 여기 있는 클러스터링 규칙은 AI 호출이 실패하거나 키가 없을 때도 판단이 멈추지 않도록
 * 하는 안전망(fallback) 역할도 겸한다 — BudgetEngine이 예산 판단에서 하는 역할과 같은 위치.
 *
 * 판정 결과는 세 가지뿐이다:
 *  - REGULAR: 정기소득자로 판단 (급여 추정 금액/입금일 제공)
 *  - IRREGULAR: 데이터는 충분한데 규칙적인 패턴이 없음 -> 프리랜서/비정기소득자로 보고 하드컷 대상
 *  - INSUFFICIENT_DATA: 아직 관측 기간(최소 2개월)이 부족해서 판단을 보류
 */
object IncomeAnalyzer {

    enum class Status { REGULAR, IRREGULAR, INSUFFICIENT_DATA }

    data class Result(
        val status: Status,
        val monthlyAmount: Int? = null,
        val payDay: Int? = null,
        val reason: String
    )

    /** 클러스터 안 금액들이 서로 이 비율 이내로 가까우면 "같은 정기 입금"으로 본다. */
    private const val AMOUNT_TOLERANCE = 0.05

    /** 클러스터 안 입금일(day-of-month)이 이 일수 이내로 모이면 "같은 주기"로 본다. */
    private const val PAYDAY_TOLERANCE_DAYS = 3

    /** 정기소득으로 판단하려면 최소 이 개월 수만큼 반복 확인돼야 한다. */
    private const val MIN_MONTHS_REQUIRED = 2

    fun analyze(transactions: List<IncomeTransaction>): Result {
        val distinctMonths = transactions.map { it.date.substring(0, 7) }.toSet()

        if (distinctMonths.size < MIN_MONTHS_REQUIRED) {
            return Result(
                status = Status.INSUFFICIENT_DATA,
                reason = "최근 ${distinctMonths.size}개월치 입금 내역만 확인돼 판단하기엔 데이터가 부족함" +
                    "(최소 ${MIN_MONTHS_REQUIRED}개월 필요)"
            )
        }

        val clusters = buildAmountClusters(transactions)

        // 서로 다른 달에 걸쳐 반복되고, 입금일도 비슷한 클러스터만 "정기" 후보로 남긴다.
        val regularCandidates = clusters.filter { cluster ->
            val months = cluster.map { it.date.substring(0, 7) }.toSet()
            if (months.size < MIN_MONTHS_REQUIRED) return@filter false
            val days = cluster.map { dayOfMonth(it.date) }
            (days.max() - days.min()) <= PAYDAY_TOLERANCE_DAYS
        }

        if (regularCandidates.isEmpty()) {
            return Result(
                status = Status.IRREGULAR,
                reason = "입금 금액·날짜가 매달 불규칙함(건당 입금 패턴) — 정기소득자 조건 미충족"
            )
        }

        // 후보가 여럿이면(월급 + 용돈처럼) 평균 금액이 가장 큰 클러스터를 급여로 간주한다.
        val best = regularCandidates.maxBy { cluster -> cluster.map { it.amount }.average() }
        val monthlyAmount = best.map { it.amount }.average().toInt()
        val payDay = best.map { dayOfMonth(it.date) }.average().toInt()

        return Result(
            status = Status.REGULAR,
            monthlyAmount = monthlyAmount,
            payDay = payDay,
            reason = "매월 ${payDay}일 전후 약 ${"%,d".format(monthlyAmount)}원이 반복 입금됨 — 정기소득 패턴으로 판단"
        )
    }

    private fun dayOfMonth(date: String): Int = date.substring(8, 10).toInt()

    /** 금액이 비슷한 입금끼리 하나의 클러스터로 묶는다 (금액이 큰 순서로 그리디하게 묶음). */
    private fun buildAmountClusters(transactions: List<IncomeTransaction>): List<List<IncomeTransaction>> {
        val clusters = mutableListOf<MutableList<IncomeTransaction>>()
        for (tx in transactions.sortedByDescending { it.amount }) {
            val cluster = clusters.find { c ->
                val avg = c.map { it.amount }.average()
                Math.abs(tx.amount - avg) / avg <= AMOUNT_TOLERANCE
            }
            if (cluster != null) cluster.add(tx) else clusters.add(mutableListOf(tx))
        }
        return clusters
    }
}

/** 계좌 연동(mock)에서 들어온 입금 거래 한 건. Transaction(지출/카드 내역)과는 별개로 관리한다. */
data class IncomeTransaction(
    val amount: Int,
    val date: String, // yyyy-MM-dd
    val memo: String = ""
)
