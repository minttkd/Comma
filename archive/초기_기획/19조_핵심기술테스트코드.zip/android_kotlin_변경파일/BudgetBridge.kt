package com.example.impulseguard

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.webkit.JavascriptInterface
import org.json.JSONArray
import org.json.JSONObject

/**
 * WebView 안의 JS(script.js)가 window.AndroidBridge.xxx(...) 형태로 호출하는 다리 역할.
 * 기존 Flask 버전에서 fetch()로 /api/... 를 호출하던 부분을, 서버 없이 이 브릿지를
 * 직접 호출하는 방식으로 바꿨을 뿐 판단 로직(BudgetEngine)은 동일하다.
 *
 * [runJs]는 AI 코멘트처럼 "나중에(비동기로) 결과가 도착했을 때" WebView 쪽 JS 함수를
 * 호출해주기 위한 콜백이다 (MainActivity가 webView.evaluateJavascript(...)로 연결해준다).
 * checkPurchase()는 신호등 판단(safe/warning/danger)은 항상 즉시 동기적으로 돌려주고,
 * AI 코멘트만 이 콜백을 통해 뒤늦게 화면에 붙는다 — AI 호출이 느리거나 실패해도
 * 핵심 판단 기능 자체는 절대 멈추지 않는다.
 */
class BudgetBridge(
    private val context: Context,
    private val runJs: (String) -> Unit
) {

    private val store = BudgetStore(context)

    @JavascriptInterface
    fun isAccessibilityServiceEnabled(): Boolean =
        PurchaseGuardService.isEnabled(context)

    @JavascriptInterface
    fun isOverlayPermissionGranted(): Boolean =
        Settings.canDrawOverlays(context)

    /**
     * 앱을 맨 처음 시작할 때 "접근성 서비스"·"다른 앱 위에 표시" 권한을 온보딩 화면에서
     * 이미 사용자에게 허락받았는지. index.html의 permissionScreen이 이 값으로,
     * 앱을 열 때마다 권한 안내 화면을 반복해서 보여줄지 곧바로 다음 단계로 넘길지 정한다.
     */
    @JavascriptInterface
    fun isPermissionOnboardingDone(): Boolean = store.isPermissionOnboardingDone()

    @JavascriptInterface
    fun markPermissionOnboardingDone() {
        store.setPermissionOnboardingDone(true)
    }

    /**
     * "계좌·카드 연동해서 고정지출 자동 불러오기"가 온보딩 전용 화면(linkAccountScreen)으로
     * 분리되면서, 한 번 마쳤는지 여부도 권한 온보딩과 같은 방식으로 기기에 저장해둔다.
     */
    @JavascriptInterface
    fun isAccountLinkOnboardingDone(): Boolean = store.isAccountLinkOnboardingDone()

    @JavascriptInterface
    fun markAccountLinkOnboardingDone() {
        store.setAccountLinkOnboardingDone(true)
    }

    @JavascriptInterface
    fun openAccessibilitySettings() {
        val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
    }

    @JavascriptInterface
    fun openOverlaySettings() {
        val overlayIntent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:${context.packageName}")
        )
        overlayIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(overlayIntent)
    }

    private fun budgetWithSummaryJson(budget: Budget): String {
        val summary = BudgetEngine.summarize(budget)
        val obj = JSONObject()
        obj.put("income", budget.income)

        val fixedArr = JSONArray()
        budget.fixedExpenses.forEach {
            fixedArr.put(JSONObject().apply {
                put("name", it.name); put("amount", it.amount); put("source", it.source)
            })
        }
        obj.put("fixed_expenses", fixedArr)

        val purchasesArr = JSONArray()
        budget.purchases.forEach {
            purchasesArr.put(JSONObject().apply {
                put("name", it.name); put("amount", it.amount); put("date", it.date)
            })
        }
        obj.put("purchases", purchasesArr)

        obj.put("summary", JSONObject().apply {
            put("fixed_total", summary.fixedTotal)
            put("spent_total", summary.spentTotal)
            put("remaining", summary.remaining)
        })
        return obj.toString()
    }

    @JavascriptInterface
    fun getBudget(): String = budgetWithSummaryJson(store.load())

    @JavascriptInterface
    fun getLinkedSubscriptions(): String {
        val arr = JSONArray()
        store.loadLinkedSubscriptions().forEach {
            arr.put(JSONObject().apply {
                put("name", it.name); put("amount", it.amount); put("source", it.source)
            })
        }
        return JSONObject().apply { put("detected_subscriptions", arr) }.toString()
    }

    /** 계좌 연동 시뮬레이션의 "원본" — 아직 고정/변동으로 나뉘지 않은 가상 거래내역 전체. */
    @JavascriptInterface
    fun getFakeTransactions(): String {
        val arr = JSONArray()
        store.loadFakeTransactions().forEach {
            arr.put(JSONObject().apply {
                put("name", it.name); put("amount", it.amount); put("date", it.date)
            })
        }
        return JSONObject().apply { put("transactions", arr) }.toString()
    }

    /**
     * "AI가 거래내역에서 고정지출만 골라내기" 기능의 시작점.
     * API 키가 있으면 즉시 {"status":"pending"}만 돌려주고, AI 분류가 끝나는 대로
     * window.onFixedExpensesClassified([...])를 호출해서 결과를 넘겨준다.
     * API 키가 없거나(아직 설정 안 함) AI 호출 자체가 실패하면, 예전처럼 하드코딩된
     * 구독 목록으로 조용히 대체한다 — "AI가 없어도 이 기능은 데모가 가능해야 한다"는 원칙.
     */
    @JavascriptInterface
    fun classifyFixedExpenses(): String {
        val apiKey = store.loadApiKey()
        val transactions = store.loadFakeTransactions()

        AiCoach.classifyFixedExpenses(apiKey, transactions) { result ->
            val items = result ?: store.loadLinkedSubscriptions().map {
                AiCoach.ClassifiedExpense(it.name, it.amount)
            }
            val arr = JSONArray()
            items.forEach {
                arr.put(JSONObject().apply { put("name", it.name); put("amount", it.amount) })
            }
            val usedAi = result != null
            runJs(
                "if (window.onFixedExpensesClassified) { " +
                    "window.onFixedExpensesClassified($arr, $usedAi); " +
                    "}"
            )
        }

        return JSONObject().apply { put("status", "pending") }.toString()
    }

    /**
     * "계좌내역 AI 자동판단" 기능의 시작점 — 사용자가 월급을 직접 입력하지 않고,
     * (가상) 최근 3개월 입금 내역을 IncomeAnalyzer(규칙 기반)로 먼저 판단한 뒤,
     * 그 판정을 사람이 읽을 문장으로 바꾼 결과를 window.onIncomePatternAnalyzed(...)로
     * 돌려준다. status가 "irregular"면 프론트엔드가 "정기 소득자를 대상으로 설계됐어요"
     * 하드컷 안내로 넘어가야 한다 — 이 판단은 여기서 절대 뒤집지 않는다.
     */
    @JavascriptInterface
    fun analyzeIncomePattern(): String {
        val transactions = store.loadFakeIncomeTransactions()
        val result = IncomeAnalyzer.analyze(transactions)

        // 판정을 즉시 저장해둔다 — "irregular"가 한 번 확정되면 앱을 재실행해도
        // 하드컷 화면이 계속 유지돼야 하기 때문(온보딩 화면 진입 즉시 상태 조회에 쓰임).
        store.saveIncomeCheckStatus(result.status.name.lowercase())

        AiCoach.explainIncomeResult(store.loadApiKey(), result) { explanation ->
            val message = explanation ?: result.reason
            val usedAi = explanation != null
            runJs(
                "if (window.onIncomePatternAnalyzed) { " +
                    "window.onIncomePatternAnalyzed(${JSONObject.quote(result.status.name.lowercase())}, " +
                    "${JSONObject.quote(message)}, $usedAi); " +
                    "}"
            )
        }

        return JSONObject().apply {
            put("status", result.status.name.lowercase())
            put("monthly_amount", result.monthlyAmount ?: JSONObject.NULL)
            put("pay_day", result.payDay ?: JSONObject.NULL)
            put("reason", result.reason)
        }.toString()
    }

    /**
     * 온보딩 화면(index.html)이 앱을 열자마자(비동기 분석을 기다리지 않고) 바로
     * 어떤 화면을 보여줄지 정할 수 있도록, 마지막으로 저장된 판정을 즉시 돌려준다.
     * 한 번도 분석한 적이 없으면 "unknown"을 돌려주고, 이 경우 프론트엔드가
     * analyzeIncomePattern()을 새로 호출해서 판정을 받아온다.
     */
    @JavascriptInterface
    fun getIncomeCheckStatus(): String = store.loadIncomeCheckStatus() ?: "unknown"

    @JavascriptInterface
    fun isIncomeConfirmed(): Boolean = store.isIncomeConfirmed()

    /**
     * 사용자가 "맞아요"(자동 감지된 금액) 또는 직접 입력한 금액으로 이번 달 수입을
     * 확정한다. IncomeAnalyzer가 "regular"로 판정했더라도, 최종 확정은 항상
     * 사용자가 누른다 — "AI 제안 + 사용자 확인" 원칙을 지키는 지점.
     */
    @JavascriptInterface
    fun confirmIncome(amount: Int): String {
        val current = store.load()
        val updated = current.copy(income = amount)
        store.save(updated)
        store.setIncomeConfirmed(true)
        return budgetWithSummaryJson(updated)
    }

    /** income과 fixed_expenses 배열을 담은 JSON 문자열을 받아 저장한다. */
    @JavascriptInterface
    fun setup(json: String): String {
        val input = JSONObject(json)
        val income = input.optInt("income", 0)

        val fixedArr = input.optJSONArray("fixed_expenses") ?: JSONArray()
        val fixed = (0 until fixedArr.length()).map { i ->
            val f = fixedArr.getJSONObject(i)
            FixedExpense(f.getString("name"), f.optInt("amount", 0), f.optString("source", "manual"))
        }.filter { it.name.isNotBlank() && it.amount > 0 }

        val current = store.load()
        val updated = current.copy(income = income, fixedExpenses = fixed)
        store.save(updated)
        if (income > 0) store.setIncomeConfirmed(true) // 대시보드에서 직접 수정한 경우도 확정으로 간주
        return budgetWithSummaryJson(updated)
    }

    /**
     * 구매를 확정하기 전, 지금 사도 되는지만 판단해서 알려준다 (저장하지 않음).
     * 신호등 판단은 여기서 즉시 계산해서 동기적으로 돌려주고, AI 코멘트는 백그라운드에서
     * 따로 요청한 뒤 준비되는 대로 window.onAiComment(...)를 호출해 화면에 붙여준다.
     */
    @JavascriptInterface
    fun checkPurchase(amount: Int, name: String): String {
        val budget = store.load()
        val summary = BudgetEngine.summarize(budget)
        val result = BudgetEngine.judge(summary.remaining, amount, budget.income)

        val itemName = name.ifBlank { "구매 항목" }
        AiCoach.generateComment(
            apiKey = store.loadApiKey(),
            budget = budget,
            summary = summary,
            judgment = result,
            itemName = itemName,
            amount = amount
        ) { comment ->
            if (comment != null) {
                runJs("if (window.onAiComment) { window.onAiComment(${JSONObject.quote(comment)}); }")
            }
        }

        return JSONObject().apply {
            put("status", result.status)
            put("message", result.message)
            put("remaining_before", result.remainingBefore)
            put("remaining_after", result.remainingAfter)
        }.toString()
    }

    /** 설정 화면에서 입력한 AI API 키를 저장한다 (기기 안에만 저장, 서버로 전송되지 않음). */
    @JavascriptInterface
    fun setApiKey(key: String) {
        store.saveApiKey(key)
    }

    @JavascriptInterface
    fun getApiKey(): String = store.loadApiKey() ?: ""

    /** 실제로 구매를 확정해서 기록에 남긴다. */
    @JavascriptInterface
    fun confirmPurchase(name: String, amount: Int): String {
        val budget = store.load()
        val updated = budget.copy(purchases = budget.purchases + Purchase(name, amount, store.todayDate()))
        store.save(updated)
        return budgetWithSummaryJson(updated)
    }

    /**
     * "포기하기"를 눌러 충동구매를 실제로 막아낸 순간을 기록한다. checkPurchase()가 돌려준
     * status를 그대로 넘겨받아 같이 저장해서, 나중에 통계/회고에서 "위험 등급을 몇 번
     * 막았는지" 같은 걸 구분할 수 있게 한다.
     */
    @JavascriptInterface
    fun cancelPurchase(name: String, amount: Int, status: String): String {
        store.addPreventedAttempt(name.ifBlank { "구매 항목" }, amount, status.ifBlank { "warning" })
        return getStats()
    }

    /** "충동구매 방지 실적" 대시보드용 이번 달 통계. AI 없이 항상 즉시 계산되는 규칙 기반 값. */
    @JavascriptInterface
    fun getStats(): String {
        val budget = store.load()
        val stats = BudgetEngine.computeStats(budget, store.currentYearMonth())
        return JSONObject().apply {
            put("total_attempts", stats.totalAttempts)
            put("prevented_count", stats.preventedCount)
            put("confirmed_count", stats.confirmedCount)
            put("prevention_rate", stats.preventionRate)
            put("saved_amount", stats.savedAmount)
            put("period_label", stats.periodLabel)
        }.toString()
    }

    /**
     * 이번 달 회고를 시작한다. 즉시 {"status":"pending"}만 돌려주고, AI 회고가 끝나는 대로
     * (또는 API 키가 없거나 실패해서 규칙 기반 요약으로 대체되는 대로) window.onMonthlyReview(...)를
     * 호출해서 결과를 넘겨준다 — classifyFixedExpenses()와 같은 패턴.
     */
    @JavascriptInterface
    fun getMonthlyReview(): String {
        val budget = store.load()
        val stats = BudgetEngine.computeStats(budget, store.currentYearMonth())

        AiCoach.generateMonthlyReview(store.loadApiKey(), budget, stats) { result ->
            val usedAi = result != null
            val text = result ?: fallbackReviewText(stats)
            runJs(
                "if (window.onMonthlyReview) { " +
                    "window.onMonthlyReview(${JSONObject.quote(text)}, $usedAi); " +
                    "}"
            )
        }

        return JSONObject().apply { put("status", "pending") }.toString()
    }

    /** AI 없이도(또는 실패해도) 항상 보여줄 수 있는, 숫자만으로 만든 최소한의 회고 문장. */
    private fun fallbackReviewText(stats: BudgetEngine.Stats): String {
        if (stats.totalAttempts == 0) return "이번 달은 아직 판단 기록이 없어요. 충동구매 감지가 시작되면 여기에 실적이 쌓여요."
        return "이번 달 총 ${stats.totalAttempts}번의 유혹 중 ${stats.preventedCount}번을 막아 " +
            "${stats.preventionRate}%의 방지율을 기록했어요. 지킨 금액은 ${"%,d".format(stats.savedAmount)}원이에요."
    }
}
