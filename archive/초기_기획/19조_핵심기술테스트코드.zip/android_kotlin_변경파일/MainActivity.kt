package com.example.impulseguard

import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity

/**
 * 앱의 유일한 화면. 초기 설정(수입/고정지출 입력, 계좌 연동 시뮬레이션)과
 * 구매 확인 화면을 WebView로 보여준다.
 *
 * 화면 자체는 웹 기술(HTML/CSS/JS, assets/web 폴더)로 만들었지만, 브라우저가 아니라
 * 이 앱 안에서만 실행되는 화면이고 서버 통신 없이 전부 기기 안에서 동작한다 — 주소창,
 * 새로고침, 브라우저 UI가 전혀 없다. 실제 "다른 앱에서 결제 버튼 감지"는 이 화면과
 * 무관하게 PurchaseGuardService(접근성 서비스)가 백그라운드에서 담당한다.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        webView = findViewById(R.id.webView)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.webViewClient = WebViewClient()
        // AI 코멘트처럼 나중에 도착하는 결과를 WebView 쪽 JS 함수 호출로 전달해주는 통로.
        // 반드시 메인 스레드에서 evaluateJavascript를 호출해야 하므로 webView.post로 감싼다.
        val bridge = BudgetBridge(this) { js -> webView.post { webView.evaluateJavascript(js, null) } }
        webView.addJavascriptInterface(bridge, "AndroidBridge")
        webView.loadUrl("file:///android_asset/web/index.html")
    }

    // 이 앱은 여러 페이지를 오가는 게 아니라 하나의 HTML 안에서 JS(showScreen())가
    // 화면을 전환하는 SPA라, webView.canGoBack()/goBack()(브라우저 페이지 히스토리)은
    // 쓸 수 없다 — 실제로는 늘 false라 기기 뒤로가기를 누르면 곧장 앱이 종료됐다.
    // 대신 JS 쪽에 "지금 화면에서 뒤로가기를 처리했는지"를 물어보고, 처리했다면
    // (예: 대시보드 -> 수입·지출을 기입하는 화면으로 전환) 앱을 종료하지 않는다.
    override fun onBackPressed() {
        webView.evaluateJavascript(
            "(typeof handleAndroidBack === 'function' && handleAndroidBack()) ? 'true' : 'false'"
        ) { result ->
            if (result != "\"true\"") {
                super.onBackPressed()
            }
        }
    }
}
