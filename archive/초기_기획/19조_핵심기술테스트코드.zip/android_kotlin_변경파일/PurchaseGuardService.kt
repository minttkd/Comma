package com.example.impulseguard

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/**
 * 크롬 확장 프로그램의 content.js와 같은 역할을, 브라우저가 아니라 안드로이드
 * 전체(다른 앱들) 위에서 하는 부분. 사용자가 설정 > 접근성에서 이 서비스를
 * 직접 켜줘야만 동작한다.
 *
 * 동작 방식: 화면이 바뀌거나 뭔가 클릭될 때마다 현재 화면의 UI 노드들을 훑어서
 * "구매하기/결제하기/주문하기" 같은 문구가 있는지 확인하고, 있으면 화면 전체 텍스트에서
 * 금액 패턴("00,000원")을 찾아 예산 판단 후 오버레이 카드를 띄운다.
 *
 * v2: 판단 카드를 띄우자마자 바로 버튼을 주지 않는다. 안전 등급이면 바로 버튼이 나오지만,
 * 주의/위험 등급이면 AI가 이전 답변에 맞춰 만든 질문으로 최대 3라운드 문답을 먼저 거치고
 * (실패하면 하드코딩된 질문으로 대체), 그다음에야 최종 버튼(구매하기/그만두기)이 나온다.
 * 위험 등급은 거기에 더해 정해진 문구를 그대로 입력해야만 "구매하기"가 눌린다 —
 * 정보 하나 보여주는 것만으로는 충동구매를 막기 약하다는 판단에 따라, "잠깐 멈춰서
 * 스스로 생각하게 만드는 마찰"을 의도적으로 넣은 것이다.
 *
 * 주의(정직하게 밝혀두는 한계): 크롬 확장 프로그램처럼 "클릭 자체를 취소"하는 게
 * 아니라, 버튼이 화면에 나타난 시점에 개입하는 방식이다. 버튼 문구가 다르거나
 * 이미지로만 된 버튼, 텍스트가 스크린샷처럼 그려진 버튼은 인식하지 못한다.
 */
class PurchaseGuardService : AccessibilityService() {

    private lateinit var overlayManager: OverlayManager
    private lateinit var store: BudgetStore

    private var lastShownAtMs = 0L
    private var lastSignature = ""

    override fun onServiceConnected() {
        super.onServiceConnected()
        overlayManager = OverlayManager(applicationContext)
        store = BudgetStore(applicationContext)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        // 우리 앱 자신의 화면에서는 동작하지 않는다 (자기 자신을 감지하는 걸 방지).
        if (event.packageName == packageName) return
        if (overlayManager.isShowing()) return

        val root = rootInActiveWindow ?: return
        val texts = mutableListOf<String>()
        collectTexts(root, texts, depth = 0)

        val joined = texts.joinToString(" ")

        // 정규식 판단(구매 버튼 문구 + 금액 추출)은 ButtonTextDetector로 분리돼 있어,
        // 실기기 없이도 정규식 자체는 단위 테스트로 검증할 수 있다(core_test/ 참고).
        val detection = ButtonTextDetector.detect(texts) ?: return

        // 짧은 시간 안에 같은 화면에 대해 반복해서 뜨는 것을 막는다 (디바운스).
        val signature = event.packageName?.toString() + "|" + joined.take(80)
        val now = System.currentTimeMillis()
        if (signature == lastSignature && now - lastShownAtMs < 4000) return

        val amount = detection.amount

        val budget = store.load()
        val summary = BudgetEngine.summarize(budget)
        val judgment = BudgetEngine.judge(summary.remaining, amount, budget.income)

        lastShownAtMs = now
        lastSignature = signature

        val itemName = "감지된 상품" // 다른 앱 화면에서는 정확한 상품명을 안정적으로 뽑을 방법이 없음(광고/배너 텍스트 혼입 가능)
        val apiKey = store.loadApiKey()

        overlayManager.show(judgment)

        // 신호등 판단과 별개로, 과거 구매 패턴을 반영한 코칭 코멘트를 백그라운드에서 추가로 붙인다.
        // 응답이 늦게 와도 오버레이가 이미 닫혔으면 appendAiComment가 조용히 무시한다.
        AiCoach.generateComment(
            apiKey = apiKey,
            budget = budget,
            summary = summary,
            judgment = judgment,
            itemName = itemName,
            amount = amount
        ) { comment -> if (comment != null) overlayManager.appendAiComment(comment) }

        val onCancel = {
            // "그만두기"를 눌러 실제로 막아낸 순간을 기록 — 앱 안 "방지 실적" 대시보드에 그대로 반영된다.
            store.addPreventedAttempt(itemName, amount, judgment.status)
            performGlobalAction(GLOBAL_ACTION_BACK)
        }
        val onContinue = { /* 실제 구매는 원래 앱 화면에서 사용자가 직접 이어서 진행 — 우리가 대신 클릭하지 않음 */ }

        if (judgment.status == "safe") {
            // 안전 등급은 문답 없이 바로 최종 버튼을 보여준다 — 추가 마찰이 필요 없다고 판단.
            overlayManager.showDecisionButtons(
                requireTyping = false,
                requiredPhrase = "",
                onCancel = onCancel,
                onContinue = onContinue
            )
        } else {
            runConversation(apiKey, budget, judgment, itemName, amount, onCancel, onContinue)
        }
    }

    /**
     * AI와 최대 [TOTAL_ROUNDS]라운드 문답을 재귀적으로 진행한다. 한 라운드가 끝나면
     * (사용자가 답을 보내면) 다음 질문을 다시 AI에게 요청하고, 라운드를 다 채우면
     * 최종 버튼을 보여준다. AI 호출이 실패해도 하드코딩된 질문으로 대체되어 문답
     * 자체(마찰 장치)는 항상 진행된다.
     */
    private fun runConversation(
        apiKey: String?,
        budget: Budget,
        judgment: BudgetEngine.Judgment,
        itemName: String,
        amount: Int,
        onCancel: () -> Unit,
        onContinue: () -> Unit
    ) {
        val history = mutableListOf<Pair<String, String>>()

        fun askRound(round: Int) {
            if (round > TOTAL_ROUNDS) {
                overlayManager.showDecisionButtons(
                    requireTyping = judgment.status == "danger",
                    requiredPhrase = CONFIRM_PHRASE,
                    onCancel = onCancel,
                    onContinue = onContinue
                )
                return
            }
            AiCoach.generateFollowupQuestion(apiKey, budget, judgment, itemName, amount, history) { aiQuestion ->
                val question = aiQuestion ?: FALLBACK_QUESTIONS.getOrElse(round - 1) {
                    "이걸 사면 지금 기분이 어떨 것 같아요?"
                }
                overlayManager.showQuestion(round, TOTAL_ROUNDS, question) { answer ->
                    history.add(question to answer)
                    askRound(round + 1)
                }
            }
        }

        askRound(1)
    }

    private fun collectTexts(node: AccessibilityNodeInfo?, out: MutableList<String>, depth: Int) {
        if (node == null || depth > 40) return
        node.text?.let { if (it.isNotBlank()) out.add(it.toString()) }
        node.contentDescription?.let { if (it.isNotBlank()) out.add(it.toString()) }
        for (i in 0 until node.childCount) {
            collectTexts(node.getChild(i), out, depth + 1)
        }
    }

    override fun onInterrupt() {
        overlayManager.dismiss()
    }

    companion object {
        private const val TOTAL_ROUNDS = 3
        private const val CONFIRM_PHRASE = "그래도 삽니다"
        private val FALLBACK_QUESTIONS = listOf(
            "지금 이걸 왜 사고 싶으신가요?",
            "이거 없이 지금까지는 어떻게 지내셨어요?",
            "내일 아침에 일어나도 여전히 사고 싶을 것 같으세요?"
        )

        /** 사용자가 설정 > 접근성에서 이 서비스를 켜뒀는지 확인한다. */
        fun isEnabled(context: Context): Boolean {
            val expectedComponent = "${context.packageName}/${PurchaseGuardService::class.java.canonicalName}"
            val enabledServices = Settings.Secure.getString(
                context.contentResolver,
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return false
            return enabledServices.split(':').any { it.equals(expectedComponent, ignoreCase = true) }
        }
    }
}
