package com.example.impulseguard

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 예산 데이터를 기기 안(SharedPreferences)에 저장/로드한다.
 * Flask 프로토타입의 data/budget.json 파일을 대신하는 역할 — 서버 없이도
 * 앱 혼자 동작하도록(오프라인) 만들기 위해 로컬 저장으로 바꿨다.
 */
class BudgetStore(context: Context) {

    private val prefs = context.getSharedPreferences("impulse_guard_budget", Context.MODE_PRIVATE)

    fun load(): Budget {
        // 저장된 데이터가 아예 없을 때(첫 실행) 빈 Budget()을 그대로 돌려준다. 예전엔
        // "친구 생일선물" 같은 일반적인 샘플 구매 내역을 하나 채워 넣었었는데, 이 서비스는
        // 배달앱 결제 버튼을 감지해서 막는 게 핵심이라 생일선물 같은 무관한 예시가
        // 오히려 헷갈렸다. 실제로도 첫 실행 시점엔 구매 기록이 없는 게 맞고, 화면 쪽
        // (script.js의 renderPurchaseList)도 이미 빈 목록을 "아직 구매 기록이 없어요."로
        // 자연스럽게 보여주도록 돼 있어서 굳이 가짜 데이터를 채울 필요가 없었다.
        val raw = prefs.getString(KEY_BUDGET, null) ?: return Budget()
        return try {
            val obj = JSONObject(raw)
            val income = obj.optInt("income", 0)

            val fixedArr = obj.optJSONArray("fixed_expenses") ?: JSONArray()
            val fixed = (0 until fixedArr.length()).map { i ->
                val f = fixedArr.getJSONObject(i)
                FixedExpense(f.getString("name"), f.getInt("amount"), f.optString("source", "manual"))
            }

            val purchasesArr = obj.optJSONArray("purchases") ?: JSONArray()
            val purchases = (0 until purchasesArr.length()).map { i ->
                val p = purchasesArr.getJSONObject(i)
                Purchase(p.getString("name"), p.getInt("amount"), p.optString("date", ""))
            }

            val preventedArr = obj.optJSONArray("prevented_attempts") ?: JSONArray()
            val prevented = (0 until preventedArr.length()).map { i ->
                val p = preventedArr.getJSONObject(i)
                PreventedAttempt(
                    p.getString("name"),
                    p.getInt("amount"),
                    p.optString("date", ""),
                    p.optString("status", "warning")
                )
            }

            Budget(income, fixed, purchases, prevented)
        } catch (e: Exception) {
            Budget()
        }
    }

    fun save(budget: Budget) {
        val obj = JSONObject()
        obj.put("income", budget.income)

        val fixedArr = JSONArray()
        budget.fixedExpenses.forEach {
            fixedArr.put(JSONObject().apply {
                put("name", it.name)
                put("amount", it.amount)
                put("source", it.source)
            })
        }
        obj.put("fixed_expenses", fixedArr)

        val purchasesArr = JSONArray()
        budget.purchases.forEach {
            purchasesArr.put(JSONObject().apply {
                put("name", it.name)
                put("amount", it.amount)
                put("date", it.date)
            })
        }
        obj.put("purchases", purchasesArr)

        val preventedArr = JSONArray()
        budget.preventedAttempts.forEach {
            preventedArr.put(JSONObject().apply {
                put("name", it.name)
                put("amount", it.amount)
                put("date", it.date)
                put("status", it.status)
            })
        }
        obj.put("prevented_attempts", preventedArr)

        prefs.edit().putString(KEY_BUDGET, obj.toString()).apply()
    }

    /** "그만두기"로 충동구매를 막아낸 순간을 기록한다 (앱 안 수동 확인, 다른 앱 감지 오버레이 공용). */
    fun addPreventedAttempt(name: String, amount: Int, status: String) {
        val budget = load()
        val updated = budget.copy(
            preventedAttempts = budget.preventedAttempts + PreventedAttempt(name, amount, todayDate(), status)
        )
        save(updated)
    }

    /** 오늘 날짜("yyyy-MM-dd"). 구매/방지 기록에 실제 날짜를 남기기 위해 쓴다. */
    fun todayDate(): String = SimpleDateFormat("yyyy-MM-dd", Locale.KOREA).format(Date())

    /** 이번 달("yyyy-MM"). 통계 집계 기간을 정하는 데 쓴다. */
    fun currentYearMonth(): String = SimpleDateFormat("yyyy-MM", Locale.KOREA).format(Date())

    /**
     * 실제 서비스라면 오픈뱅킹/카드사 API로 정기결제 내역을 가져오는 부분.
     * 이번 프로토타입에서는 가상 데이터로 시뮬레이션한다 (Flask 버전과 동일한 데이터).
     */
    fun loadLinkedSubscriptions(): List<FixedExpense> = listOf(
        FixedExpense("넷플릭스", 13500, "linked"),
        FixedExpense("헬스장 정기결제", 49000, "linked"),
        FixedExpense("유튜브 프리미엄", 14900, "linked"),
        FixedExpense("스포티파이", 10900, "linked")
    )

    /**
     * "AI가 거래내역에서 고정지출만 골라내는" 기능(AiClassifier)에 쓰는 원시 데이터.
     * 실제 오픈뱅킹 대신, 최근 2개월치 가상 거래내역을 하드코딩해서 시뮬레이션한다.
     * 넷플릭스·헬스장·유튜브·스포티파이·KT통신요금은 매달 같은 금액이 반복되는 고정지출처럼,
     * 스타벅스·배달의민족·올리브영·무신사·GS25는 한 번만 나오는 변동지출처럼 섞어뒀다 —
     * AI가 "반복되는 이름 vs 한 번뿐인 이름"을 실제로 구분해볼 수 있게 만든 구성이다.
     */
    fun loadFakeTransactions(): List<Transaction> = listOf(
        Transaction("넷플릭스", 13500, "2026-08-05"),
        Transaction("넷플릭스", 13500, "2026-09-05"),
        Transaction("스타벅스", 6300, "2026-09-02"),
        Transaction("헬스장 정기결제", 49000, "2026-08-01"),
        Transaction("헬스장 정기결제", 49000, "2026-09-01"),
        Transaction("배달의민족", 18900, "2026-09-10"),
        Transaction("유튜브 프리미엄", 14900, "2026-08-15"),
        Transaction("유튜브 프리미엄", 14900, "2026-09-15"),
        Transaction("올리브영", 32000, "2026-09-08"),
        Transaction("스포티파이", 10900, "2026-08-20"),
        Transaction("스포티파이", 10900, "2026-09-20"),
        Transaction("무신사", 89000, "2026-09-12"),
        Transaction("KT 통신요금", 55000, "2026-08-25"),
        Transaction("KT 통신요금", 55000, "2026-09-25"),
        Transaction("GS25", 4500, "2026-09-14")
    )

    /**
     * "계좌내역 AI 자동판단"(IncomeAnalyzer) 기능에 쓰는 원시 입금 내역.
     * 실제 오픈뱅킹 대신, 최근 3개월치 가상 입금 내역을 하드코딩해서 시뮬레이션한다.
     * 매달 25일 전후로 같은 금액(급여)이 들어오는 정기소득자 시나리오를 기본값으로 뒀다 —
     * 프리랜서/비정기소득자 시나리오는 IncomeAnalyzerTest(core_test/)에서 별도로 검증한다.
     */
    fun loadFakeIncomeTransactions(): List<IncomeTransaction> = listOf(
        IncomeTransaction(2_450_000, "2026-07-25", "급여이체"),
        IncomeTransaction(2_450_000, "2026-08-25", "급여이체"),
        IncomeTransaction(2_450_000, "2026-09-25", "급여이체"),
        IncomeTransaction(50_000, "2026-08-10", "용돈-부모님"),
        IncomeTransaction(30_000, "2026-09-03", "중고거래정산")
    )

    /**
     * AI 코멘트 기능(AiCoach)에 쓰는 API 키. 기기 안에만 저장되고 서버로 전송되지 않으며,
     * 여기 저장된 값은 AiCoach가 api.anthropic.com에 직접 요청을 보낼 때 헤더로만 쓰인다.
     */
    fun saveApiKey(key: String) {
        prefs.edit().putString(KEY_AI_API_KEY, key).apply()
    }

    fun loadApiKey(): String? = prefs.getString(KEY_AI_API_KEY, null)

    /**
     * IncomeAnalyzer가 마지막으로 내린 판정("regular"/"irregular"/"insufficient_data")을
     * 기기에 저장해둔다. 앱을 다시 켤 때마다 계좌 분석을 새로 돌리지 않고도, "irregular"였다면
     * 곧바로 하드컷 화면부터 보여줄 수 있게 하기 위함이다 — 하드컷은 한 번 확정되면
     * 그 세션이 끝나도 계속 유지돼야 의미가 있다.
     */
    fun saveIncomeCheckStatus(status: String) {
        prefs.edit().putString(KEY_INCOME_STATUS, status).apply()
    }

    fun loadIncomeCheckStatus(): String? = prefs.getString(KEY_INCOME_STATUS, null)

    /** 사용자가 "맞아요"/직접입력 중 하나로 소득을 확정한 적이 있는지. */
    fun setIncomeConfirmed(confirmed: Boolean) {
        prefs.edit().putBoolean(KEY_INCOME_CONFIRMED, confirmed).apply()
    }

    fun isIncomeConfirmed(): Boolean = prefs.getBoolean(KEY_INCOME_CONFIRMED, false)

    /**
     * "접근성 서비스"·"다른 앱 위에 표시" 권한을 앱 맨 처음 시작할 때 한 번 물어봤는지.
     * 한 번 true가 되면(둘 다 켜진 걸 확인한 뒤) 다시는 온보딩에서 이 단계를 반복하지
     * 않는다 — 이후에 사용자가 시스템 설정에서 권한을 꺼버리는 것까지는 여기서 막지 않는다
     * (그 경우는 실제 감지가 그냥 동작하지 않는 것으로 자연스럽게 드러난다).
     */
    fun setPermissionOnboardingDone(done: Boolean) {
        prefs.edit().putBoolean(KEY_PERMISSION_ONBOARDING_DONE, done).apply()
    }

    fun isPermissionOnboardingDone(): Boolean = prefs.getBoolean(KEY_PERMISSION_ONBOARDING_DONE, false)

    /**
     * "계좌·카드 연동해서 고정지출 자동 불러오기"를 앱을 처음 시작할 때 한 번 거쳤는지.
     * 예전에는 대시보드(초기 설정) 안에 상시 있는 버튼이었지만, 온보딩 전용 화면
     * (linkAccountScreen)으로 분리되면서 한 번 마치면 다시 보여주지 않기 위해 필요하다.
     */
    fun setAccountLinkOnboardingDone(done: Boolean) {
        prefs.edit().putBoolean(KEY_ACCOUNT_LINK_ONBOARDING_DONE, done).apply()
    }

    fun isAccountLinkOnboardingDone(): Boolean = prefs.getBoolean(KEY_ACCOUNT_LINK_ONBOARDING_DONE, false)

    companion object {
        private const val KEY_BUDGET = "budget_json"
        private const val KEY_AI_API_KEY = "ai_api_key"
        private const val KEY_INCOME_STATUS = "income_check_status"
        private const val KEY_INCOME_CONFIRMED = "income_confirmed"
        private const val KEY_PERMISSION_ONBOARDING_DONE = "permission_onboarding_done"
        private const val KEY_ACCOUNT_LINK_ONBOARDING_DONE = "account_link_onboarding_done"
    }
}
