let currentBudget = null;
// 저장 전 화면에서만 관리하는 수입·지출 임시 목록. 정기 수입도 이 안에 같은 방식의
// 항목(type: "income")으로 들어있다 — 예전엔 linkedIncome이라는 별도 값이었지만,
// "수입도 직접 추가/삭제할 수 있어야 한다"는 요구에 맞춰 지출과 같은 목록으로 합쳤다.
// (백엔드 Budget.income은 여전히 숫자 하나뿐이라, 저장 시 type:"income" 항목들의
// 합계 하나로 합쳐진다 — 여러 건을 추가해도 다음에 불러오면 합계 한 줄로 보인다.)
let localFixedRows = [];
let lastIncomeAnalysis = null; // analyzeIncomePattern()의 동기 반환값(status/monthly_amount 등)을 잠깐 기억
let incomeAnalysisMessage = ""; // 규칙 기반 reason -> AI 문장으로 나중에 교체될 수 있는 설명 텍스트
let incomeConfirmed = false; // 이번 화면 방문에서 정기 수입이 이미 확정됐는지(수정 모드는 항상 true)
let addType = "expense"; // "+ 직접 추가" 폼의 지출/수입 토글 상태

// AI가 감지했지만 아직 사용자가 확인하지 않은 고정지출 후보들. 예전엔 감지되는
// 즉시 목록에 자동으로 추가됐는데, "정기 수입처럼 고정지출도 확인받아야 한다"는
// 요구에 맞춰 정기 수입과 같은 확인 절차를 거치게 했다.
let pendingExpenseItems = [];
let pendingExpenseUsedAi = false;
let expenseClassificationDone = false; // classifyFixedExpenses() 콜백이 이번 연동에서 한 번이라도 도착했는지

// renderDetectedConfirm()이 그려주는 체크박스 확인 목록. 한 번에 전부 확정하는 게
// 아니라, 감지된 정기 수입·고정지출 후보 각각을 체크박스로 보여주고(체크 옆에
// 수입/지출 배지도 함께 표시) 기본은 전부 체크된 상태로 시작한다 — 사용자가
// 잘못됐다고 판단한 항목만 체크를 해제해서 뺀 뒤 "추가하기"를 누르면 체크된
// 것만 반영된다.
let detectedCandidates = [];
let detectedHasIncomeCandidate = false; // 이번 후보 목록에 정기 수입 후보가 포함돼 있었는지

const won = (n) => Number(n).toLocaleString("ko-KR") + "원";

// ---- 화면 전환: "화면"(계좌연동/하드컷/메인앱) 중 하나만 보여준다 ----
// 권한 팝업(permissionModal)은 이 화면 전환과 별개다 — 화면이 아니라 지금 화면 위에
// 겹쳐 뜨는 모달이라서, 어떤 화면이 떠 있든 그 위에 얹혔다가 사라진다.
function showScreen(id) {
  ["linkAccountScreen", "hardcutScreen", "mainApp"].forEach((s) => {
    document.getElementById(s).style.display = s === id ? "block" : "none";
  });
}

// ---- 0) 앱 시작 순서: (권한 팝업, 필요하면) -> ①고정 수입·지출(계좌연동, 정기 수입 확인 포함) -> ②메인 앱 ----
// 예전엔 "소득 확인"이 별도 첫 화면이었는데, 계좌 연동 시점에 정기 수입도 같이
// 판정하도록 합쳐서 화면 단계를 하나 줄였다. 화면 전환은 소득/계좌연동 진행
// 상태만으로 정해지고, 권한 팝업은 그 위에 별도로 얹힌다.
function initApp() {
  routeToScreen();
  if (!AndroidBridge.isPermissionOnboardingDone()) {
    showPermissionModal();
  }
}

// 이미 지난 실행에서 끝낸 단계는 다시 묻지 않는다: 소득이 "정기 확정"이고 고정지출
// 연동까지 끝났으면 곧바로 메인 화면으로, "비정기(하드컷)"면 곧바로 하드컷 화면으로 간다.
// 그 외(최초 실행/데이터 부족/소득 미확정)는 전부 고정 수입·지출 화면부터 시작한다.
function routeToScreen() {
  const status = AndroidBridge.getIncomeCheckStatus(); // "unknown" | "regular" | "irregular" | "insufficient_data"

  if (status === "irregular") {
    showHardCut(null);
    return;
  }
  if (status === "regular" && AndroidBridge.isIncomeConfirmed() && AndroidBridge.isAccountLinkOnboardingDone()) {
    showMainApp();
    return;
  }

  showLinkAccountScreen();
}

// ---- 권한 팝업: 접근성 서비스 / 다른 앱 위에 표시 — 앱을 맨 처음 시작할 때 딱 한 번
// 사용자에게 직접 허락을 구한다. 별도 화면이 아니라 지금 화면 위에 뜨는 팝업(모달)이다.
// 실제 감지 기능이 이 두 권한 없이는 전혀 동작하지 않으므로, 둘 다 켜져야 닫힌다. ----
function showPermissionModal() {
  document.getElementById("permissionModal").style.display = "flex";
  refreshPermissionStatus();
}

function hidePermissionModal() {
  document.getElementById("permissionModal").style.display = "none";
}

function isPermissionModalOpen() {
  return document.getElementById("permissionModal").style.display !== "none";
}

function tryClosePermissionModal(auto) {
  refreshPermissionStatus();
  const bothOn = AndroidBridge.isAccessibilityServiceEnabled() && AndroidBridge.isOverlayPermissionGranted();
  const msg = document.getElementById("permissionCheckMsg");

  if (!bothOn) {
    // 자동 재확인(설정 화면에 다녀온 직후)일 때는 아직 하나가 꺼져 있어도 조용히 넘어간다 —
    // "버튼을 눌렀는데도 안 켜졌다"는 안내는 사용자가 직접 버튼을 눌렀을 때만 보여준다.
    if (!auto) msg.style.display = "block";
    return;
  }
  msg.style.display = "none";
  AndroidBridge.markPermissionOnboardingDone();
  hidePermissionModal(); // 뒤에 있던 화면(계좌연동/메인앱)은 이미 떠 있으므로 그대로 이어진다.
}

// ---- ① 고정 수입·지출(계좌 연동) 화면: 앱을 시작할 때 가장 먼저 보이는 화면이자,
// 메인 화면의 "수정하기"로도 다시 들어오는 화면이다. 최초 온보딩 때는 "계좌 연동"
// 버튼 한 번으로 (1) 정기 수입 판정(하드컷 포함)과 (2) 고정지출 자동 분류를 함께
// 처리한다 — 예전엔 소득 확인이 별도 첫 화면이었는데, 계좌 내역을 어차피 한 번에
// 불러오는 거라 두 단계를 하나로 합쳤다. 이미 온보딩을 마친 사용자(수정 모드)는
// 정기 수입을 다시 묻지 않고 고정지출만 다시 확인·수정한다. ----
function showLinkAccountScreen() {
  showScreen("linkAccountScreen");
  // classifyFixedExpenses() 콜백(onFixedExpensesClassified)이 버튼 문구를 원래대로
  // 되돌릴 때 쓸 원본 문구를 미리 기억해둔다 — 사용자가 버튼을 누르기 전에
  // beginDetection()이 먼저 호출되는 경우(아래 "재실행" 분기)에도 필요하다.
  const linkBtn = document.getElementById("linkBtn");
  linkBtnOriginalText = linkBtnOriginalText || linkBtn.innerText;

  const budget = JSON.parse(AndroidBridge.getBudget());
  // 정기 수입은 더 이상 별도 값이 아니라, 이 목록 맨 위의 "정기 수입" 항목(type:"income")
  // 하나로 들어간다 — 그래야 지출과 똑같이 직접 추가/삭제가 가능해진다.
  const incomeRow = budget.income > 0 ? [{ name: "정기 수입", amount: budget.income, source: "linked", type: "income" }] : [];
  const expenseRows = (budget.fixed_expenses || []).map((e) => ({ ...e, type: "expense" }));
  localFixedRows = [...incomeRow, ...expenseRows];

  const editMode = AndroidBridge.isAccountLinkOnboardingDone();
  // 정기 수입은 "계좌연동까지 다 끝난 수정 모드"뿐 아니라, isIncomeConfirmed()가 이미
  // true인 경우(예: 수입은 확정했는데 고정지출 연동 도중 앱이 재시작된 경우)에도
  // 이미 확정된 것으로 본다 — 그래야 확정한 수입을 다시 묻지 않는다.
  incomeConfirmed = editMode || AndroidBridge.isIncomeConfirmed();

  setAddType("expense");

  const incomeStepBox = document.getElementById("incomeStepBox");
  if (incomeConfirmed) {
    incomeStepBox.style.display = "none";
  } else {
    // 별도 안내 문구 없이, 판정이 시작될 때(계좌 연동 버튼 클릭 또는 이전 판정 이어받기)
    // 비로소 이 박스가 보인다 — 그전까지는 화면에 빈 박스를 미리 보여주지 않는다.
    incomeStepBox.style.display = "none";
    document.getElementById("incomeConfirmBox").style.display = "none";
    document.getElementById("manualIncomeBox").style.display = "none";
    document.getElementById("reanalyzeIncomeBtn").style.display = "none";

    // 재실행 등으로 이전에 이미 한 번 판정된 적이 있으면(정기소득이지만 아직 확정
    // 전이거나, 데이터 부족 판정) 버튼을 다시 누르지 않아도 바로 이어서 보여준다.
    // "regular"라면 고정지출 확인 카드도 함께 필요하므로 분류도 같이 다시 돌린다
    // (그래야 renderDetectedConfirm()이 무한정 대기하지 않고 확인 카드를 그려준다).
    const savedStatus = AndroidBridge.getIncomeCheckStatus();
    if (savedStatus !== "unknown") {
      beginDetection();
    }
  }

  renderFixedList();

  // 버튼은 온보딩 때든(계좌연동 아직 안 끝남) 기기 뒤로가기로 다시 들어온
  // 경우(이미 한 번 끝남, 수정 모드)든 항상 "계속하기"다 — 이 화면 자체가 이미
  // "뒤로 돌아온" 상태이므로, 화면 안에 또 "뒤로가기" 버튼을 두면 오히려 헷갈린다.
  // 버튼을 누르면 두 경우 모두 finishAccountLinking()이 지금까지 담긴 내용을
  // 저장하고 다음(메인 앱)으로 진행한다 — 저장/취소를 나누는 두 버튼이 아니라
  // 하나를 그대로 재사용한다.
}

function finishAccountLinking() {
  // 최초 온보딩인데 아직 정기 수입이 확정되지 않았으면(계좌 연동을 아예 안 눌렀거나,
  // 판정 결과를 아직 확인/정정하지 않은 경우) 여기서 막는다 — 정기 수입 확정은
  // 하드컷 판정을 겸하는 단계라 건너뛸 수 없다.
  if (!AndroidBridge.isAccountLinkOnboardingDone() && !incomeConfirmed) {
    alert("정기 수입을 먼저 확인해주세요.");
    return;
  }
  // 백엔드는 수입을 여전히 숫자 하나(income)로만 받으므로, type:"income" 항목들의
  // 합계를 그 값으로 보내고 나머지는 지출로 보낸다.
  const incomeTotal = localFixedRows
    .filter((r) => r.type === "income")
    .reduce((sum, r) => sum + r.amount, 0);
  const expenseRows = localFixedRows
    .filter((r) => r.type !== "income")
    .map(({ name, amount, source }) => ({ name, amount, source }));
  const updated = JSON.parse(
    AndroidBridge.setup(JSON.stringify({ income: incomeTotal, fixed_expenses: expenseRows }))
  );
  currentBudget = updated;
  AndroidBridge.markAccountLinkOnboardingDone();
  showMainApp();
}

function showMainApp() {
  showScreen("mainApp");
  loadBudget();
}

function showHardCut(reason) {
  showScreen("hardcutScreen");
  if (reason) document.getElementById("hardcutReason").innerText = reason;
}

// ---- 기기 뒤로가기 버튼: MainActivity.onBackPressed()가 evaluateJavascript로 이
// 함수를 호출해서 "지금 화면에서 뒤로가기를 어떻게 처리할지"를 JS 쪽에 물어본다.
// true를 돌려주면 여기서 화면 전환으로 처리했다는 뜻이라 안드로이드 기본 동작
// (앱 종료)을 막고, false면 안드로이드가 기본 동작을 하게 둔다. 대시보드(mainApp)
// 에는 더 이상 "수정하기" 버튼이 없으므로, 뒤로가기가 수입·지출을 기입하는 화면
// (linkAccountScreen, 수정 모드)으로 돌아가는 유일한 통로다.
function handleAndroidBack() {
  if (document.getElementById("mainApp").style.display !== "none") {
    showLinkAccountScreen();
    return true;
  }
  return false;
}

// IncomeAnalyzer(규칙 기반)가 즉시 내려주는 판정을 먼저 받고, AI가 만든 자연어 설명은
// onIncomePatternAnalyzed() 콜백으로 뒤늦게 도착한다 — 신호등 판단 + AI 코멘트와 같은 패턴.
// "계좌 연동" 버튼(최초 온보딩)이나 "다시 확인하기"에서 호출된다.
function analyzeIncomeForLinking() {
  document.getElementById("incomeStepBox").style.display = "block";
  document.getElementById("incomeConfirmBox").style.display = "none";
  document.getElementById("manualIncomeBox").style.display = "none";
  document.getElementById("reanalyzeIncomeBtn").style.display = "none";

  const statusBox = document.getElementById("incomeCheckStatus");
  statusBox.innerHTML =
    '<span class="ai-badge muted">확인 중</span> 입금 내역 확인 중...';

  const result = JSON.parse(AndroidBridge.analyzeIncomePattern());
  lastIncomeAnalysis = result;
  incomeAnalysisMessage = result.reason;
  applyIncomeStatus(result.status, result.reason, false);
}

function reanalyzeIncome() {
  analyzeIncomeForLinking();
}

// BudgetBridge.analyzeIncomePattern()이 AI 설명을 마치면(또는 실패해서 규칙 기반 문구로
// 대체되면) Android 쪽에서 이 함수를 호출해준다. status 판정 자체는 절대 바뀌지 않는다.
function onIncomePatternAnalyzed(status, message, usedAi) {
  applyIncomeStatus(status, message, usedAi);
}

function applyIncomeStatus(status, message, usedAi) {
  incomeAnalysisMessage = message;
  if (lastIncomeAnalysis) lastIncomeAnalysis.usedAi = usedAi;
  const statusBox = document.getElementById("incomeCheckStatus");
  const badge = usedAi
    ? '<span class="ai-badge">AI</span>'
    : '<span class="ai-badge muted">판단</span>';

  if (status === "regular") {
    statusBox.innerHTML = badge + " 정기소득 패턴이 감지됐어요.";
    // 고정지출 자동 분류(classifyFixedExpenses)가 이미 끝났다면 여기서 바로 함께
    // 확인 카드를 띄운다 — 아직 안 끝났으면 renderDetectedConfirm()이 조용히
    // 대기하고, onFixedExpensesClassified()가 도착했을 때 마저 그려준다.
    renderDetectedConfirm();
  } else if (status === "irregular") {
    // 프리랜서·비정기소득자 -> 하드컷. BudgetBridge가 이미 이 상태를 저장해뒀으므로
    // 다음 실행부터는 initApp()이 분석 없이 곧바로 이 화면부터 보여준다.
    showHardCut(message);
  } else {
    // insufficient_data: 아직 판단할 근거(2개월치 데이터)가 부족한 경우 — 막지 않고,
    // 그 사이엔 직접 입력으로 시작할 수 있게 한다. 이 경우에도 고정지출이
    // 감지되면(정기 수입과 같은 규칙으로) 별도로 확인을 받는다.
    statusBox.innerHTML = badge + " " + message;
    document.getElementById("manualIncomeBox").style.display = "block";
    document.getElementById("reanalyzeIncomeBtn").style.display = "inline-block";
    renderDetectedConfirm();
  }
}

// AI 감지 결과(정기 수입 판정 + 고정지출 자동 분류)를 체크박스 목록 한 카드에
// 모아서 보여준다. 한 번에 전부 확정/거절하는 대신, 항목마다 체크박스를 두고
// 기본은 전부 체크된 상태로 시작한다 — 사용자가 잘못됐다고 판단한 항목만 체크를
// 해제해서 빼면 된다(정기 수입도 같은 방식으로 통일). classifyFixedExpenses()
// 콜백이 아직 안 왔으면(expenseClassificationDone===false) 정기 수입만 먼저
// 판정됐다고 서둘러 확인 카드를 띄우지 않고 기다린다.
function renderDetectedConfirm() {
  if (!expenseClassificationDone) return;
  if (lastIncomeAnalysis && lastIncomeAnalysis.status === "irregular") return; // 이미 하드컷으로 전환됨

  const showIncomeDecision = !incomeConfirmed && lastIncomeAnalysis && lastIncomeAnalysis.status === "regular";
  const hasItems = pendingExpenseItems.length > 0;

  if (!showIncomeDecision && !hasItems) {
    document.getElementById("incomeConfirmBox").style.display = "none";
    maybeHideIncomeStepBox();
    return;
  }

  detectedHasIncomeCandidate = showIncomeDecision;
  detectedCandidates = [];
  if (showIncomeDecision) {
    const amount = lastIncomeAnalysis.monthly_amount;
    const payDay = lastIncomeAnalysis.pay_day;
    detectedCandidates.push({
      kind: "income",
      label: "정기 수입",
      detail: amount ? `매월 ${payDay}일 전후 · 약 ${won(amount)}` : "",
      amount,
      checked: true,
    });
  }
  pendingExpenseItems.forEach((item) => {
    detectedCandidates.push({
      kind: "expense",
      label: item.name,
      detail: won(item.amount),
      amount: item.amount,
      checked: true,
    });
  });

  const listEl = document.getElementById("detectedCandidatesList");
  listEl.innerHTML = detectedCandidates
    .map(
      (c, i) => `
      <label class="candidate-row ${c.kind}">
        <input type="checkbox" checked onclick="toggleDetectedCandidate(${i})" />
        <span class="badge ${c.kind}">${c.kind === "income" ? "수입" : "지출"}</span>
        <span class="candidate-name">${c.label}</span>
        <span class="candidate-detail">${c.detail}</span>
      </label>
    `
    )
    .join("");

  document.getElementById("incomeConfirmBox").style.display = "block";
}

// 정기 수입과 고정지출 확인이 둘 다 끝나서(또는 애초에 보여줄 게 없어서) 더 이상
// 확인 카드가 필요 없으면 이 단계 박스 전체를 닫는다. incomeConfirmed가 아직
// false거나(수동 입력 대기 중) 확인 대기 중인 고정지출이 남아 있으면 열어둔다.
function maybeHideIncomeStepBox() {
  if (incomeConfirmed && pendingExpenseItems.length === 0) {
    document.getElementById("incomeStepBox").style.display = "none";
  }
}

// 체크박스를 눌러 후보 하나를 켜고/끄는 것 — 삭제하듯이 체크를 해제하면 그 항목은
// "추가하기"를 눌러도 반영되지 않는다.
function toggleDetectedCandidate(i) {
  if (detectedCandidates[i]) {
    detectedCandidates[i].checked = !detectedCandidates[i].checked;
  }
}

// "추가하기" — 체크된 후보만 반영한다(정기 수입도 고정지출도 같은 규칙). 정기
// 수입 후보가 있었는데 체크가 해제돼 확정되지 않았다면, 정기 수입 확정은
// 하드컷 판정을 겸하는 단계라 건너뛸 수 없으므로 직접 입력 칸을 대신 열어준다.
function commitDetectedCandidates() {
  detectedCandidates.forEach((c) => {
    if (!c.checked) return;
    if (c.kind === "income") {
      if (!c.amount) return;
      AndroidBridge.confirmIncome(c.amount);
      incomeConfirmed = true;
      localFixedRows.unshift({ name: "정기 수입", amount: c.amount, source: "ai-linked", type: "income" });
    } else {
      localFixedRows.push({ name: c.label, amount: c.amount, source: "ai-linked", type: "expense" });
    }
  });

  const incomeStillNeeded = detectedHasIncomeCandidate && !incomeConfirmed;
  detectedCandidates = [];
  pendingExpenseItems = [];

  document.getElementById("incomeConfirmBox").style.display = "none";
  if (incomeStillNeeded) {
    document.getElementById("manualIncomeBox").style.display = "block";
    document.getElementById("reanalyzeIncomeBtn").style.display = "inline-block";
  } else {
    maybeHideIncomeStepBox();
  }
  renderFixedList();
}

function confirmManualIncome() {
  const amount = Number(document.getElementById("manualIncome").value);
  if (!amount) {
    alert("금액을 입력해주세요.");
    return;
  }
  AndroidBridge.confirmIncome(amount);
  incomeConfirmed = true;
  localFixedRows.unshift({ name: "정기 수입", amount, source: "manual", type: "income" });
  document.getElementById("manualIncomeBox").style.display = "none";
  document.getElementById("reanalyzeIncomeBtn").style.display = "none";
  maybeHideIncomeStepBox();
  renderFixedList();
}

// ---- 1) 앱 시작: AndroidBridge(로컬 저장소) -> 화면 ----
// 예전 Flask 버전은 fetch()로 서버에 물어봤지만, 여기서는 서버가 없으므로
// WebView 안의 JS가 AndroidBridge.getBudget()을 "동기적으로" 바로 호출해서 값을 받는다.
function loadBudget() {
  const budget = JSON.parse(AndroidBridge.getBudget());
  currentBudget = budget;

  renderSummary(budget.summary);
  renderPurchaseList(budget.purchases);

  refreshStats();
}

// ---- "충동구매 방지 실적" 카드: 이번 달 통계(AI 없이 즉시 계산) + AI 월간 회고(비동기) ----
function refreshStats() {
  const stats = JSON.parse(AndroidBridge.getStats());
  document.getElementById("statPrevented").innerText = stats.prevented_count + "회";
  document.getElementById("statRate").innerText = stats.prevention_rate + "%";
  document.getElementById("statSaved").innerText = won(stats.saved_amount);

  const reviewBox = document.getElementById("monthlyReview");
  reviewBox.innerHTML = '<span class="ai-badge">AI</span> 이번 달 회고 불러오는 중...';
  AndroidBridge.getMonthlyReview(); // 결과는 onMonthlyReview 콜백으로 도착
}

// BudgetBridge.getMonthlyReview()가 (AI 또는 규칙 기반 대체로) 회고를 완성하면 Android 쪽에서 호출해준다.
function onMonthlyReview(text, usedAi) {
  const reviewBox = document.getElementById("monthlyReview");
  if (!reviewBox) return;
  const badge = usedAi ? '<span class="ai-badge">AI</span>' : '<span class="ai-badge muted">요약</span>';
  reviewBox.innerHTML = badge + " " + text;
}

function renderSummary(summary) {
  const remainingEl = document.getElementById("remaining");
  remainingEl.innerText = won(summary.remaining);
  remainingEl.className =
    "summary-amount " + (summary.remaining < 0 ? "danger" : "");
  document.getElementById("summarySub").innerText =
    `고정지출 ${won(summary.fixed_total)} · 이미 쓴 금액 ${won(summary.spent_total)}`;
}

// 항목 옆에 붙는 배지: 수입이면 "수입"(강조색), 지출이면 자동 연동 여부만 "지출"로 표시.
function rowLabel(item) {
  if (item.type === "income") return '<span class="badge income">수입</span>';
  if (item.source === "ai-linked") return '<span class="badge ai">지출</span>';
  if (item.source === "linked") return '<span class="badge">지출</span>';
  return "";
}

// 수입·지출을 같은 목록·같은 방식(삭제 가능)으로 한 번에 보여준다 — AI가 자동으로
// 채운 항목이든 사용자가 직접 추가한 항목이든 구분 없이 다룬다. 정기 수입 항목만
// 카드 배경색으로 살짝 구분해서(income-row) 한눈에 알아보기 쉽게 한다.
function renderFixedList() {
  const el = document.getElementById("fixedList");
  if (localFixedRows.length === 0) {
    el.innerHTML = '<div class="empty">등록된 수입·지출이 없어요.</div>';
    return;
  }
  el.innerHTML = localFixedRows
    .map((item, i) => {
      const rowClass = "fixed-row" + (item.type === "income" ? " income-row" : "");
      return `
      <div class="${rowClass}">
        <span>${item.name}${rowLabel(item)}</span>
        <span>${won(item.amount)}</span>
        <button class="remove-btn" onclick="removeFixedRow(${i})">삭제</button>
      </div>
    `;
    })
    .join("");
}

// "+ 직접 추가" 위의 지출/수입 토글 — 어느 쪽으로 추가할지를 고른다.
function setAddType(type) {
  addType = type;
  document.getElementById("typeExpenseBtn").className =
    "type-toggle-btn" + (type === "expense" ? " active" : "");
  document.getElementById("typeIncomeBtn").className =
    "type-toggle-btn" + (type === "income" ? " active" : "");
}

function addFixedRow() {
  const name = document.getElementById("fixedName").value.trim();
  const amount = Number(document.getElementById("fixedAmount").value);
  if (!name || !amount) {
    alert("이름과 금액을 입력해주세요.");
    return;
  }
  localFixedRows.push({ name, amount, source: "manual", type: addType });
  renderFixedList();
  document.getElementById("fixedName").value = "";
  document.getElementById("fixedAmount").value = "";
}

function removeFixedRow(index) {
  localFixedRows.splice(index, 1);
  renderFixedList();
}

// ---- 사용자가 직접 입력하지 않아도 되도록: 계좌/카드 연동 + AI 고정지출 분류 시뮬레이션 ----
// AI에게 거래내역을 보내 "매달 반복되는 고정지출"로 보이는 것만 골라내게 한다
// (원본 거래내역 미리보기는 화면에 따로 보여주지 않는다 — 감지 결과 확인 카드
// 하나로 충분하다고 판단해 없앴다). AI 응답은 비동기라 여기서는 "분석 중..."
// 상태만 보여주고, 실제 후보 목록은 onFixedExpensesClassified()가 콜백으로
// 불려올 때 채워진다. 그 후보는 곧장 추가되지 않고, 정기 수입 판정과 함께
// renderDetectedConfirm() 체크박스 확인 카드에 모여서, 사용자가 체크된 것만
// "추가하기"로 확정해야 비로소 목록에 반영된다.
let linkBtnOriginalText = "";

// 고정지출 자동 분류 + (필요하면) 정기 수입 판정을 함께 시작한다. "계좌 연동해서
// 불러오기" 버튼 클릭(linkAccount())과, 화면을 다시 열었을 때 이전에 이미
// 판정이 시작됐던 경우(showLinkAccountScreen()의 재실행 분기)가 이 함수를 같이 쓴다
// — 어느 경로든 고정지출 확인 카드가 언젠가는 반드시 그려지도록 하기 위함이다.
function beginDetection() {
  pendingExpenseItems = [];
  pendingExpenseUsedAi = false;
  expenseClassificationDone = false;
  AndroidBridge.classifyFixedExpenses(); // 결과는 onFixedExpensesClassified 콜백으로 도착

  // 최초 온보딩(정기 수입 미확정) 때만 이 시점에 정기 수입도 함께 판정한다 —
  // 수정 모드에선 이미 확정돼 있으므로 계좌를 다시 연동해도 수입은 다시 묻지 않는다.
  if (!incomeConfirmed) {
    analyzeIncomeForLinking();
  } else {
    lastIncomeAnalysis = null;
  }
}

function linkAccount() {
  const btn = document.getElementById("linkBtn");
  linkBtnOriginalText = linkBtnOriginalText || btn.innerText;
  btn.disabled = true;
  btn.innerText = "🤖 AI 분석 중...";

  beginDetection();
}

// BudgetBridge.classifyFixedExpenses()가 백그라운드에서 AI 호출을 마치면(또는 키가 없어서
// 예시 목록으로 대체하면) Android 쪽에서 이 함수를 호출해준다. 예전엔 여기서 곧장
// 목록에 추가했지만, 이제는 후보로만 잠깐 들고 있다가 renderDetectedConfirm()의
// 확인 카드(정기 수입과 같은 절차)를 거쳐야 실제로 추가된다.
function onFixedExpensesClassified(items, usedAi) {
  const btn = document.getElementById("linkBtn");
  pendingExpenseItems = items.filter((item) => !localFixedRows.some((r) => r.name === item.name));
  pendingExpenseUsedAi = usedAi;
  expenseClassificationDone = true;

  const showIncomeDecision = !incomeConfirmed && lastIncomeAnalysis && lastIncomeAnalysis.status === "regular";
  if (!showIncomeDecision && pendingExpenseItems.length === 0) {
    // 확인할 새 항목이 없으면(예: 수정 모드에서 다시 연동했는데 이미 다 있는 경우)
    // 버튼에 짧게 안내만 띄우고 원래 문구로 되돌린다.
    btn.innerText = "새로 감지된 항목이 없어요";
    setTimeout(() => {
      btn.innerText = linkBtnOriginalText;
      btn.disabled = false;
    }, 2500);
  } else {
    btn.innerText = linkBtnOriginalText;
    btn.disabled = false;
  }

  renderDetectedConfirm();
}

// ---- 2) 구매 기록 표시 ----
// 대시보드 안에서 직접 "이거 사도 될까?"를 입력해 확인하던 수동 체크 기능은 없앴다 —
// 실제 판단은 PurchaseGuardService가 다른 앱(배달앱)의 결제 버튼을 감지했을 때
// 오버레이로 자동으로 뜨므로, 이 화면에서 같은 걸 다시 입력하게 할 이유가 없다.
// 여기 쌓이는 구매 기록도 그 자동 감지 흐름(그만두기=방지 실적 / 결제 계속 진행)에서 온다.
function renderPurchaseList(purchases) {
  const el = document.getElementById("purchaseList");
  if (!purchases || purchases.length === 0) {
    el.innerText = "아직 구매 기록이 없어요.";
    return;
  }
  el.innerHTML = purchases
    .map((p) => `<div class="purchase-row"><span>${p.name}</span><span>${won(p.amount)}</span></div>`)
    .join("");
}

// ---- 권한 팝업의 두 가지 권한 상태 표시 ----
// 실제 감지/오버레이는 이 팝업과 무관하게 PurchaseGuardService가 백그라운드에서 하고,
// 여기서는 그 서비스가 켜져 있는지 상태만 보여주고 설정 화면으로 이동시켜준다.
function refreshPermissionStatus() {
  const a11yOn = AndroidBridge.isAccessibilityServiceEnabled();
  const overlayOn = AndroidBridge.isOverlayPermissionGranted();

  const a11yBadge = document.getElementById("a11yBadge");
  a11yBadge.innerText = a11yOn ? "켜짐" : "꺼짐";
  a11yBadge.className = "status-badge " + (a11yOn ? "on" : "off");

  const overlayBadge = document.getElementById("overlayBadge");
  overlayBadge.innerText = overlayOn ? "켜짐" : "꺼짐";
  overlayBadge.className = "status-badge " + (overlayOn ? "on" : "off");
}

function openA11ySettings() {
  AndroidBridge.openAccessibilitySettings();
}

function openOverlaySettingsUi() {
  AndroidBridge.openOverlaySettings();
}

// 시스템 설정 화면에 다녀온 뒤 앱으로 돌아오면 권한이 바뀌어 있을 수 있으므로,
// 권한 팝업이 떠 있는 동안은 포그라운드로 돌아올 때마다 상태를 다시 읽고,
// 그 사이 둘 다 켜졌으면 사용자가 버튼을 또 누르지 않아도 팝업이 자동으로 닫힌다.
document.addEventListener("visibilitychange", () => {
  if (document.visibilityState === "visible" && isPermissionModalOpen()) {
    tryClosePermissionModal(true);
  }
});

initApp();
