# -*- coding: utf-8 -*-
"""
"계좌내역 AI 자동판단"의 규칙 기반 핵심 로직(IncomeAnalyzer) 파이썬 포팅.

원본은 app/src/main/java/com/example/impulseguard/IncomeAnalyzer.kt (코틀린).
클러스터링 규칙과 임계값을 1:1로 그대로 옮겼다. 실제 서비스에서는 이 판정 결과를
AiCoach.explainIncomeResult()가 자연어 확인 문장으로 바꿔 사용자에게 보여주지만,
"AI가 없어도/실패해도 판단 자체는 항상 나온다"는 이 프로젝트의 설계 원칙에 따라
여기 있는 규칙 기반 판정이 실제로 맞물려 동작하는지 검증하는 게 이 테스트의 목적이다.

판정은 세 가지뿐이다:
  - regular            : 정기소득자로 판단 (급여 추정 금액/입금일 제공)
  - irregular          : 데이터는 충분한데 규칙적 패턴이 없음 -> 프리랜서/비정기소득자 하드컷 대상
  - insufficient_data   : 관측 기간(최소 2개월) 부족 -> 판단 보류
"""
from dataclasses import dataclass

AMOUNT_TOLERANCE = 0.05        # 클러스터 내 금액 오차 허용 범위
PAYDAY_TOLERANCE_DAYS = 3      # 같은 클러스터로 볼 입금일 오차
MIN_MONTHS_REQUIRED = 2        # 정기소득으로 판단하기 위한 최소 관측 개월 수


@dataclass(frozen=True)
class IncomeTransaction:
    amount: int
    date: str  # yyyy-MM-dd
    memo: str = ""


@dataclass(frozen=True)
class Result:
    status: str  # "regular" | "irregular" | "insufficient_data"
    reason: str
    monthly_amount: int | None = None
    pay_day: int | None = None


def _day_of_month(date: str) -> int:
    return int(date[8:10])


def _year_month(date: str) -> str:
    return date[:7]


def _build_amount_clusters(transactions: list[IncomeTransaction]) -> list[list[IncomeTransaction]]:
    """금액이 비슷한 입금끼리 하나의 클러스터로 묶는다 (금액 큰 순서로 그리디하게 묶음)."""
    clusters: list[list[IncomeTransaction]] = []
    for tx in sorted(transactions, key=lambda t: t.amount, reverse=True):
        target = None
        for cluster in clusters:
            avg = sum(t.amount for t in cluster) / len(cluster)
            if abs(tx.amount - avg) / avg <= AMOUNT_TOLERANCE:
                target = cluster
                break
        if target is not None:
            target.append(tx)
        else:
            clusters.append([tx])
    return clusters


def analyze(transactions: list[IncomeTransaction]) -> Result:
    distinct_months = {_year_month(t.date) for t in transactions}

    if len(distinct_months) < MIN_MONTHS_REQUIRED:
        return Result(
            status="insufficient_data",
            reason=(
                f"최근 {len(distinct_months)}개월치 입금 내역만 확인돼 판단하기엔 데이터가 "
                f"부족함(최소 {MIN_MONTHS_REQUIRED}개월 필요)"
            ),
        )

    clusters = _build_amount_clusters(transactions)

    regular_candidates = []
    for cluster in clusters:
        months = {_year_month(t.date) for t in cluster}
        if len(months) < MIN_MONTHS_REQUIRED:
            continue
        days = [_day_of_month(t.date) for t in cluster]
        if (max(days) - min(days)) <= PAYDAY_TOLERANCE_DAYS:
            regular_candidates.append(cluster)

    if not regular_candidates:
        return Result(
            status="irregular",
            reason="입금 금액·날짜가 매달 불규칙함(건당 입금 패턴) — 정기소득자 조건 미충족",
        )

    best = max(regular_candidates, key=lambda c: sum(t.amount for t in c) / len(c))
    # 코틀린 원본의 Double.toInt()는 반올림이 아니라 소수점 이하를 버림(truncate) — 동일하게 맞춘다.
    monthly_amount = int(sum(t.amount for t in best) / len(best))
    pay_day = int(sum(_day_of_month(t.date) for t in best) / len(best))

    return Result(
        status="regular",
        monthly_amount=monthly_amount,
        pay_day=pay_day,
        reason=f"매월 {pay_day}일 전후 약 {monthly_amount:,}원이 반복 입금됨 — 정기소득 패턴으로 판단",
    )
