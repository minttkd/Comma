# -*- coding: utf-8 -*-
"""
"계좌내역 AI 자동판단"의 규칙 기반 핵심(IncomeAnalyzer) 테스트.

이번 학기 새로 확정된 정책 두 가지를 직접 검증한다:
  1) 사용자가 월급을 직접 입력하지 않고도(자기보고 스크리닝 폐지), 입금 내역만으로
     정기소득자 여부를 판단할 수 있는가.
  2) 프리랜서/비정기소득자는 "하드컷"(서비스 이용 자체를 막음) 대상으로 정확히
     걸러지는가 — 즉, 애매하게 "정기"로 잘못 판정해서 하드컷을 피해가면 안 된다.
"""
import unittest

from income_analyzer import analyze, IncomeTransaction as T


class IncomeAnalyzerTest(unittest.TestCase):

    def test_regular_salaried_worker_is_detected(self):
        # BudgetStore.loadFakeIncomeTransactions()의 기본 mock 데이터와 동일한 시나리오:
        # 매달 25일 전후로 254만원이 들어오고, 용돈/중고거래 같은 소액이 한 번씩 섞여 있음.
        transactions = [
            T(2_450_000, "2026-07-25", "급여이체"),
            T(2_450_000, "2026-08-25", "급여이체"),
            T(2_450_000, "2026-09-25", "급여이체"),
            T(50_000, "2026-08-10", "용돈-부모님"),
            T(30_000, "2026-09-03", "중고거래정산"),
        ]
        result = analyze(transactions)
        self.assertEqual(result.status, "regular")
        self.assertEqual(result.monthly_amount, 2_450_000)
        self.assertEqual(result.pay_day, 25)

    def test_freelancer_irregular_income_is_hard_cut_target(self):
        # 프리랜서: 건당으로 금액도 날짜도 매번 다르게 들어옴 -> irregular로 판정돼야
        # 프론트엔드가 "정기 소득자를 대상으로 설계됐어요" 하드컷 안내로 넘어갈 수 있다.
        transactions = [
            T(800_000, "2026-07-03", "프로젝트A 정산"),
            T(1_200_000, "2026-07-19", "프로젝트B 정산"),
            T(450_000, "2026-08-08", "프로젝트C 정산"),
            T(2_100_000, "2026-08-22", "프로젝트D 정산"),
            T(300_000, "2026-09-14", "프로젝트E 정산"),
        ]
        result = analyze(transactions)
        self.assertEqual(result.status, "irregular")
        self.assertIsNone(result.monthly_amount)

    def test_single_month_history_is_insufficient_data(self):
        # "2,3개월 계좌 내역이 있다는 전제" 이전 단계 — 관측 기간이 부족하면
        # regular도 irregular도 아닌 별도 상태로 보류해야 한다(오판 방지).
        result = analyze([T(2_450_000, "2026-09-25", "급여이체")])
        self.assertEqual(result.status, "insufficient_data")
        self.assertIn("2개월", result.reason)

    def test_payday_within_tolerance_still_counts_as_regular(self):
        # 급여일이 매달 정확히 같은 날짜가 아니라 주말/공휴일 때문에 며칠씩 밀리는
        # 현실적인 경우(24~26일)도 정기소득으로 인정돼야 한다.
        transactions = [
            T(2_000_000, "2026-07-24", "급여이체"),
            T(2_000_000, "2026-08-26", "급여이체"),
            T(2_000_000, "2026-09-25", "급여이체"),
        ]
        result = analyze(transactions)
        self.assertEqual(result.status, "regular")

    def test_payday_beyond_tolerance_is_not_regular(self):
        # 금액은 매달 같아도 입금일이 5일/20일/25일처럼 들쭉날쭉하면(변동 소득 성격)
        # 정기소득으로 잘못 판정하면 안 된다.
        transactions = [
            T(2_000_000, "2026-07-05"),
            T(2_000_000, "2026-08-20"),
            T(2_000_000, "2026-09-25"),
        ]
        result = analyze(transactions)
        self.assertEqual(result.status, "irregular")

    def test_amount_variation_within_five_percent_still_clusters(self):
        # 성과급/수당이 붙어 매달 금액이 조금씩(5% 이내) 달라지는 경우도 같은
        # 정기소득 클러스터로 묶여야 한다.
        transactions = [
            T(2_000_000, "2026-07-25"),
            T(2_050_000, "2026-08-25"),
            T(2_080_000, "2026-09-25"),
        ]
        result = analyze(transactions)
        self.assertEqual(result.status, "regular")

    def test_amount_variation_beyond_five_percent_does_not_cluster(self):
        # 반대로 금액이 매달 15% 안팎으로 크게 뛰면(급여로 보기 어려움) 정기로 묶이면 안 된다.
        transactions = [
            T(2_000_000, "2026-07-25"),
            T(2_300_000, "2026-08-25"),
            T(2_600_000, "2026-09-25"),
        ]
        result = analyze(transactions)
        self.assertEqual(result.status, "irregular")

    def test_largest_recurring_cluster_is_chosen_over_smaller_ones(self):
        # 월급(정기) + 매달 나가는 소액 이체(예: 가족 용돈 정산)가 둘 다 "규칙적"으로
        # 반복돼도, 급여 추정 금액은 더 큰 쪽 클러스터를 기준으로 삼아야 한다.
        transactions = [
            T(2_450_000, "2026-07-25"), T(2_450_000, "2026-08-25"), T(2_450_000, "2026-09-25"),
            T(100_000, "2026-07-01"), T(100_000, "2026-08-01"), T(100_000, "2026-09-01"),
        ]
        result = analyze(transactions)
        self.assertEqual(result.status, "regular")
        self.assertEqual(result.monthly_amount, 2_450_000)
        self.assertEqual(result.pay_day, 25)


if __name__ == "__main__":
    unittest.main()
