# -*- coding: utf-8 -*-
"""
"버튼 텍스트 감지" 정규식/판단 로직 테스트.

여기 있는 texts 리스트들은 실제 배달의민족/요기요/쿠팡이츠 주문·결제 화면에서
흔히 나타나는 문구 구성을 흉내낸 것이다(화면 캡처 대신, PurchaseGuardService가
AccessibilityNodeInfo에서 실제로 모으는 형태 — 버튼 라벨/금액 텍스트 등 짧은
문자열들의 리스트 — 를 그대로 재현했다).
"""
import unittest

from button_text_detector import detect, Detection


class ButtonTextDetectorTest(unittest.TestCase):

    def test_baemin_style_order_screen_detects_amount(self):
        texts = ["매장 정보", "1인분 추가", "총 주문금액", "13,900원", "주문하기"]
        self.assertEqual(detect(texts), Detection(13900, "주문하기"))

    def test_yogiyo_style_payment_screen_detects_amount(self):
        texts = ["할인쿠폰 적용", "총 결제금액", "21,500원", "결제하기"]
        self.assertEqual(detect(texts), Detection(21500, "결제하기"))

    def test_coupang_eats_style_quick_pay_with_spacing(self):
        texts = ["리뷰 이벤트 참여", "바로 결제", "9,000원"]
        self.assertEqual(detect(texts), Detection(9000, "바로 결제"))

    def test_confirm_variants_are_recognized(self):
        self.assertEqual(detect(["결제확정", "32,000원"]), Detection(32000, "결제확정"))
        self.assertEqual(detect(["구매확정", "7,700원"]), Detection(7700, "구매확정"))

    def test_amount_without_comma_still_detected(self):
        # 배달앱에 따라 3자리 콤마 구분 없이 "9000원" 형태로만 표시하는 경우도 있다.
        self.assertEqual(detect(["결제하기", "9000원"]), Detection(9000, "결제하기"))

    def test_cart_add_button_is_not_a_purchase_trigger(self):
        # "담기"는 아직 결제 직전이 아니므로 감지되면 안 된다 (오탐지 방지 케이스).
        texts = ["장바구니 담기", "13,900원", "메뉴 더보기"]
        self.assertIsNone(detect(texts))

    def test_unrelated_feed_screen_has_no_match(self):
        texts = ["좋아요 128", "댓글 32개 보기", "공유하기"]
        self.assertIsNone(detect(texts))

    def test_purchase_button_without_visible_amount_is_not_judged(self):
        # 금액을 못 찾으면 판단 불가 -> None. "정보 없이 개입하지 않는다"는 설계를 검증.
        texts = ["구매하기"]
        self.assertIsNone(detect(texts))

    def test_amount_alone_without_purchase_keyword_is_ignored(self):
        texts = ["오늘의 특가", "13,900원", "찜하기"]
        self.assertIsNone(detect(texts))

    def test_known_limitation_amount_pattern_requires_at_least_4_digits(self):
        # 알려진 한계: 금액 정규식이 [\d,]{4,}원 이라 3자리 이하 금액("500원" 등)은
        # 감지되지 않는다. 배달앱 최소 주문금액을 고려하면 실사용 영향은 작지만,
        # PPT의 "인식 실패 시 정규식 조정" 대응 계획에 해당하는 케이스라 명시적으로 남겨둔다.
        texts = ["결제하기", "500원"]
        self.assertIsNone(detect(texts))

    def test_multiple_amounts_on_screen_picks_first_match(self):
        # 할인 전/후 금액이 함께 보이는 화면에서는 정규식이 먼저 매치되는 금액을 사용한다
        # (현재 구현의 알려진 단순화 지점 — 실기기 검증 시 "할인 전 금액"이 먼저 뜨는 레이아웃이면
        # 오탐지로 이어질 수 있어 실기기 테스트 항목에 포함해야 함).
        texts = ["정상가 25,000원", "할인가 19,900원", "결제하기"]
        result = detect(texts)
        self.assertIsNotNone(result)
        self.assertEqual(result.amount, 25000)


if __name__ == "__main__":
    unittest.main()
