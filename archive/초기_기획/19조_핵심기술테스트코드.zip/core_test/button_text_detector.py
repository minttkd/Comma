# -*- coding: utf-8 -*-
"""
"버튼 텍스트 감지" 핵심 로직의 파이썬 포팅.

원본은 app/src/main/java/com/example/impulseguard/ButtonTextDetector.kt (코틀린).
정규식과 판단 순서를 1:1로 그대로 옮겼다 — 이 파일은 새로운 구현이 아니라,
코틀린 코드가 실제 배달앱 문구들에 대해 옳게 동작하는지를 안드로이드 실기기 없이
먼저 검증하기 위한 것이다 (이 팀은 예전에도 Flask 프로토타입으로 먼저 로직을
검증한 뒤 코틀린으로 옮긴 전례가 있다 — BudgetEngine.kt 주석 참고).

왜 코틀린을 직접 실행해서 테스트하지 않았는지: 이 샌드박스 환경에는 안드로이드 SDK가
없고(AccessibilityService는 애초에 실기기/에뮬레이터 없이는 단위 테스트 불가), 게다가
이 네트워크에서는 Maven Central/Gradle Plugin Portal 접근도 막혀 있어 순수 코틀린
JVM 모듈조차 컴파일할 수 없었다(직접 시도해서 확인함). 그래서 "정규식·판단 로직
자체가 맞는지"를 지금 당장 실행 가능한 형태로 검증하기 위해 파이썬으로 포팅했다.
"""
import re

# 코틀린 원본과 동일한 정규식 (Regex 문법 차이 없음 — re 모듈로 그대로 이식 가능)
AMOUNT_PATTERN = re.compile(r"[\d,]{4,}\s*원")
KEYWORD_PATTERN = re.compile(r"구매하기|결제하기|주문하기|바로\s*구매|바로\s*결제|구매확정|결제확정")


class Detection:
    def __init__(self, amount: int, matched_keyword: str):
        self.amount = amount
        self.matched_keyword = matched_keyword

    def __repr__(self):
        return f"Detection(amount={self.amount}, matched_keyword={self.matched_keyword!r})"

    def __eq__(self, other):
        return (
            isinstance(other, Detection)
            and self.amount == other.amount
            and self.matched_keyword == other.matched_keyword
        )


def detect(texts: list[str]) -> Detection | None:
    """
    화면에서 모은 텍스트 노드들(버튼 라벨, contentDescription 등)을 받아
    구매 버튼 + 금액이 함께 감지되면 Detection을, 아니면 None을 돌려준다.

    금액을 못 찾으면 판단 자체가 불가능하므로 None을 돌려준다 — 코틀린 원본과 동일하게
    "버튼은 눌렸는데 얼마인지 모른 채로 예산 판단을 내리는" 상황을 만들지 않는다.
    """
    joined = " ".join(texts)

    keyword_match = KEYWORD_PATTERN.search(joined)
    if not keyword_match:
        return None

    amount_match = AMOUNT_PATTERN.search(joined)
    if not amount_match:
        return None

    raw = amount_match.group(0).replace(",", "").replace("원", "").strip()
    if not raw.isdigit():
        return None

    return Detection(amount=int(raw), matched_keyword=keyword_match.group(0))
