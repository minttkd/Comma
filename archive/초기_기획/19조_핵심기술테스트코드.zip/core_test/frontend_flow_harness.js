// -*- coding: utf-8 -*-
// script.js(웹뷰 프론트엔드)의 계좌연동(정기 수입 확인 포함)/하드컷 분기 + 권한 팝업
// 로직을 실제 브라우저/기기 없이 Node vm으로 실행해서 검증하는 테스트 하네스.
// jsdom 등 외부 패키지 없이, script.js가 실제로 사용하는 DOM API
// (getElementById/style/value/innerText/innerHTML, addEventListener)만 최소로
// 흉내낸 가짜 document를 만들어 붙인다.
//
// 목적: index.html의 실제 id들과 어긋나지 않는지, 세 가지 소득판정
// (regular/irregular/insufficient_data) 분기 + 계좌연동(linkAccountScreen, 정기 수입
// 확인을 함께 처리) + 권한 팝업(permissionModal, 화면이 아니라 그 위에 겹쳐 뜨는
// 모달)이 실제로 올바르게 동작하는지를 "정적 검토"가 아니라 코드를 실행해서 확인한다.
//
// (구조 변경 메모) 예전엔 "소득 확인"이 별도 첫 화면(onboardingScreen)이었는데,
// "계좌 연동" 버튼을 누르면 거래내역에서 고정지출뿐 아니라 정기 수입 패턴까지
// 같이 읽어오는 게 자연스러워서 linkAccountScreen 하나로 합쳤다. 이 파일의 시나리오도
// 그 병합된 흐름 기준으로 다시 짰다.
const fs = require("fs");
const path = require("path");
const vm = require("vm");

// 두 가지 배치 형태를 모두 지원한다:
//  1) 전체 안드로이드 프로젝트 옆에서 실행할 때(core_test/ + ImpulseGuardApp/ 나란히 존재)
//  2) 이 제출용 zip만 풀었을 때(core_test/ + android_web_변경파일/ 나란히 존재)
const CANDIDATE_WEB_DIRS = [
  path.join(__dirname, "..", "ImpulseGuardApp", "ImpulseGuardApp", "app", "src", "main", "assets", "web"),
  path.join(__dirname, "..", "android_web_변경파일"),
];
const WEB_DIR = CANDIDATE_WEB_DIRS.find((d) => fs.existsSync(path.join(d, "index.html")));
if (!WEB_DIR) {
  console.error("index.html을 찾을 수 없습니다. 다음 경로들을 확인했습니다:\n" + CANDIDATE_WEB_DIRS.join("\n"));
  process.exit(1);
}
const SCRIPT_PATH = path.join(WEB_DIR, "script.js");
const HTML_PATH = path.join(WEB_DIR, "index.html");

// "화면"으로 취급되는 최상위 블록들(showScreen()이 관리하는 대상). 권한 팝업
// (permissionModal)은 화면이 아니라 그 위에 얹히는 모달이라 이 목록에 넣지 않고,
// 항상 별도로("modalOpen") 확인한다.
const SCREEN_IDS = ["linkAccountScreen", "hardcutScreen", "mainApp"];

// id 목록뿐 아니라, 그 태그에 style="display:none" 같은 인라인 스타일이 있으면
// 초기 display 값까지 함께 읽어온다. 모든 가짜 엘리먼트가 display:""로 시작하면
// permissionModal/incomeStepBox처럼 "실제로는 처음에 style="display:none"으로
// 숨겨져 있는" 엘리먼트가 스크립트가 손대기도 전에 "열려 있다"고 잘못 판정된다.
// class 속성도 함께 읽어서 초기 className으로 쓴다.
function extractInitialDisplays(html) {
  const displays = {};
  const tagRe = /<[a-zA-Z][a-zA-Z0-9]*\b[^>]*>/g;
  let tag;
  while ((tag = tagRe.exec(html))) {
    const idMatch = tag[0].match(/\bid="([^"]+)"/);
    if (!idMatch) continue;
    let display = ""; // 인라인 style이 없으면 "none이 아닌 상태"로 취급(실제로도 기본 표시됨)
    const styleMatch = tag[0].match(/style="([^"]*)"/);
    if (styleMatch) {
      const dispMatch = styleMatch[1].match(/display\s*:\s*([a-zA-Z]+)/);
      if (dispMatch) display = dispMatch[1];
    }
    const classMatch = tag[0].match(/\bclass="([^"]*)"/);
    displays[idMatch[1]] = { display, className: classMatch ? classMatch[1] : "", text: "" };
  }
  // id가 달린 태그 중, 안에 중첩 태그 없이 텍스트만 들어있는 "단순한" 경우
  // (버튼 등)는 그 초기 텍스트도 함께 읽어와서, script.js가 굳이 건드리지 않아도
  // 실제 HTML 기본 문구(예: linkAccountContinueBtn의 기본 문구 "계속하기")가
  // 가짜 DOM에도 그대로 반영되게 한다 — 안 그러면 "script.js가 이 문구를 명시적으로
  // 세팅하지 않는다"는 게 "빈 문자열이 기본값이다"로 잘못 검증돼버린다.
  const simpleTagRe = /<([a-zA-Z][a-zA-Z0-9]*)\b([^>]*)>([^<]*)<\/\1>/g;
  let m;
  while ((m = simpleTagRe.exec(html))) {
    const attrs = m[2];
    const text = m[3];
    const idMatch = attrs.match(/\bid="([^"]+)"/);
    if (!idMatch || !(idMatch[1] in displays)) continue;
    displays[idMatch[1]].text = text.trim();
  }
  return displays;
}

function makeElement(initial) {
  const s = initial || {};
  return { style: { display: s.display || "" }, innerHTML: "", innerText: s.text || "", value: "", className: s.className || "", disabled: false };
}

function runScenario(name, androidBridgeStub) {
  const html = fs.readFileSync(HTML_PATH, "utf-8");
  const displays = extractInitialDisplays(html);
  const elements = {};
  Object.keys(displays).forEach((id) => (elements[id] = makeElement(displays[id])));

  const document = {
    getElementById: (id) => {
      if (!(id in elements)) throw new Error(`getElementById("${id}") — index.html에 없는 id`);
      return elements[id];
    },
    addEventListener: () => {},
    visibilityState: "visible",
  };

  const sandbox = {
    document,
    window: {},
    AndroidBridge: androidBridgeStub,
    alert: (msg) => { sandbox.__lastAlert = msg; },
    setTimeout: () => {}, // linkAccount()의 버튼 문구 복원 타이머는 검증 대상이 아니므로 실행하지 않음
    console,
    Number,
    JSON,
  };
  vm.createContext(sandbox);

  const code = fs.readFileSync(SCRIPT_PATH, "utf-8");
  vm.runInContext(code, sandbox, { filename: "script.js" });
  // script.js 맨 아래에서 initApp()이 이미 자동 호출됐다.

  const visible = SCREEN_IDS.filter((id) => elements[id].style.display !== "none");
  const modalOpen = elements.permissionModal.style.display !== "none";

  console.log(`[${name}] 최종 화면: ${visible.join(", ") || "(없음)"}${modalOpen ? " + 권한 팝업 열림" : ""}`);
  return { elements, visible, modalOpen, sandbox };
}

let failures = 0;
function assertEqual(actual, expected, msg) {
  const a = JSON.stringify(actual);
  const e = JSON.stringify(expected);
  if (a !== e) {
    console.error(`  ❌ FAIL: ${msg} (expected ${e}, got ${a})`);
    failures++;
  } else {
    console.log(`  ✅ ${msg}`);
  }
}

// 기본 브릿지 스텁 — 메인 앱(loadBudget/refreshStats 등)이 항상 필요로 하는
// 최소한의 메서드들을 공통으로 깔아두고, 시나리오별로 overrides로 덮어쓴다.
function baseBridge(overrides) {
  return Object.assign(
    {
      isPermissionOnboardingDone: () => true,
      isAccessibilityServiceEnabled: () => true,
      isOverlayPermissionGranted: () => true,
      markPermissionOnboardingDone: () => {},
      getIncomeCheckStatus: () => "unknown",
      isIncomeConfirmed: () => false,
      isAccountLinkOnboardingDone: () => false,
      markAccountLinkOnboardingDone: () => {},
      confirmIncome: () => "{}",
      getBudget: () => JSON.stringify({ income: 0, fixed_expenses: [], purchases: [], summary: { fixed_total: 0, spent_total: 0, remaining: 0 } }),
      setup: (json) => json,
      getFakeTransactions: () => JSON.stringify({ transactions: [{ name: "넷플릭스", amount: 13500, date: "2026-09-05" }] }),
      classifyFixedExpenses: () => {},
      getStats: () => JSON.stringify({ prevented_count: 0, prevention_rate: 0, saved_amount: 0 }),
      getMonthlyReview: () => {},
    },
    overrides
  );
}

// ---- 시나리오 1: 최초 실행(권한은 이미 끝났다고 가정) -> 계좌연동 화면으로 바로 진입.
// 아직 "계좌 연동" 버튼을 누르기 전이라, 별도 안내 문구 없이 수입 확인 박스 자체가
// 숨겨져 있다(빈 박스를 미리 보여주지 않음 — "계좌 연동을 누르면 정기 수입도 함께
// 확인해요" 같은 문구가 없어졌다). 고정지출 목록엔 "정기 수입 0원" 같은 항목이
// 보이지 않는다(확정 전이므로 생략) ----
{
  const bridge = baseBridge({});
  const { elements, visible, modalOpen } = runScenario("1) 최초 실행 -> 계좌연동 화면(수입 확인 전)", bridge);
  assertEqual(visible, ["linkAccountScreen"], "계좌연동 화면으로 진입(확정 전이라 메인앱으로 넘어가지 않음)");
  assertEqual(modalOpen, false, "권한 온보딩이 이미 끝났으므로 팝업은 뜨지 않음");
  assertEqual(elements.incomeStepBox.style.display, "none", "계좌 연동을 누르기 전에는 안내 문구 없이 수입 확인 박스 자체가 숨겨져 있음");
  assertEqual(elements.incomeConfirmBox.style.display, "none", "계좌 연동을 누르기 전이라 확인 카드는 아직 안 뜸");
  assertEqual(elements.fixedList.innerHTML.includes("정기 수입"), false, "수입이 아직 확정 전이라 목록에 정기 수입 항목이 없음");
  assertEqual(elements.fixedList.innerHTML.includes("등록된 수입·지출이 없어요."), true, "빈 목록 문구가 수입·지출 통합 표현으로 바뀜");
}

// ---- 시나리오 2: "계좌 연동" 버튼 클릭 -> regular 판정 -> 정기 수입 확인 박스가 열림.
// 다만 확인 카드 자체는 고정지출 자동 분류(classifyFixedExpenses) 콜백이 도착하기
// 전까지는 뜨지 않는다 — 정기 수입만 먼저 판정됐다고 서둘러 카드를 띄우지 않고,
// 고정지출까지 함께 모아서 한 번에 확인하도록 통일했기 때문이다. 콜백이 도착하면
// (여기서는 감지된 고정지출이 없다고 가정) 비로소 정기 수입 확인 카드가 뜬다 ----
{
  const bridge = baseBridge({
    analyzeIncomePattern: () =>
      JSON.stringify({ status: "regular", monthly_amount: 2450000, pay_day: 25, reason: "매월 25일 전후 약 2,450,000원이 반복 입금됨" }),
  });
  const { elements, sandbox } = runScenario("2) 계좌 연동 클릭, regular 판정", bridge);
  sandbox.linkAccount();
  assertEqual(elements.incomeStepBox.style.display, "block", "계좌 연동을 누른 순간 수입 확인 박스가 비로소 나타남");
  assertEqual(elements.incomeConfirmBox.style.display, "none", "고정지출 분류 콜백이 아직 안 왔으므로 확인 카드는 아직 안 뜸");

  sandbox.onFixedExpensesClassified([], false); // 이번엔 새로 감지된 고정지출이 없다고 가정
  assertEqual(elements.incomeConfirmBox.style.display, "block", "고정지출 분류가 끝나면 그제서야 정기소득 확인 카드가 표시됨");
  assertEqual(
    elements.detectedCandidatesList.innerHTML.includes("정기 수입") &&
      elements.detectedCandidatesList.innerHTML.includes("매월 25일 전후 · 약 2,450,000원"),
    true,
    "감지된 정기 수입이 체크박스 후보 목록에 채워짐"
  );
  assertEqual((elements.detectedCandidatesList.innerHTML.match(/checkbox/g) || []).length, 1, "감지된 고정지출이 없으면 정기 수입 후보 하나만 체크박스로 뜸");
}

// ---- 시나리오 3: "계좌 연동" 버튼 클릭 -> irregular 판정 -> 그 자리에서 곧바로 하드컷 화면으로 ----
{
  const bridge = baseBridge({
    analyzeIncomePattern: () =>
      JSON.stringify({ status: "irregular", monthly_amount: null, pay_day: null, reason: "입금 금액·날짜가 매달 불규칙함 — 정기소득자 조건 미충족" }),
  });
  const { elements, sandbox } = runScenario("3) 계좌 연동 클릭, irregular 판정", bridge);
  sandbox.linkAccount();
  const visibleAfter = SCREEN_IDS.filter((id) => sandbox.document.getElementById(id).style.display !== "none");
  assertEqual(visibleAfter, ["hardcutScreen"], "계좌연동 화면에서 곧바로 하드컷 화면으로 전환됨");
  assertEqual(elements.hardcutReason.innerText, "입금 금액·날짜가 매달 불규칙함 — 정기소득자 조건 미충족", "하드컷 사유 문구가 채워짐");
}

// ---- 시나리오 4: 이미 지난 실행에서 irregular로 확정된 적이 있음 -> 계좌연동 화면을
// 거치지 않고 재분석 없이 곧바로 하드컷 ----
{
  let analyzeCalled = false;
  const bridge = baseBridge({
    getIncomeCheckStatus: () => "irregular",
    analyzeIncomePattern: () => { analyzeCalled = true; return JSON.stringify({ status: "irregular", reason: "x" }); },
  });
  const { visible } = runScenario("4) 재실행, 저장된 상태가 irregular", bridge);
  assertEqual(visible, ["hardcutScreen"], "재분석 없이 바로 하드컷 화면");
  assertEqual(analyzeCalled, false, "analyzeIncomePattern()이 다시 호출되지 않음(불필요한 재분석 방지)");
}

// ---- 시나리오 5: regular+확정 + 계좌연동까지 이미 끝남 -> 재분석/재연동 없이 곧바로 메인 앱 ----
{
  let analyzeCalled = false;
  const bridge = baseBridge({
    getIncomeCheckStatus: () => "regular",
    isIncomeConfirmed: () => true,
    isAccountLinkOnboardingDone: () => true,
    analyzeIncomePattern: () => { analyzeCalled = true; return "{}"; },
    getBudget: () => JSON.stringify({ income: 2450000, fixed_expenses: [], purchases: [], summary: { fixed_total: 0, spent_total: 0, remaining: 2450000 } }),
  });
  const { visible } = runScenario("5) 재실행, 소득확정+계좌연동 모두 끝남", bridge);
  assertEqual(visible, ["mainApp"], "계좌연동 화면 없이 바로 메인 앱으로 진입");
  assertEqual(analyzeCalled, false, "이미 확정된 경우 계좌 재분석을 하지 않음");
}

// ---- 시나리오 6: regular+확정이지만 계좌연동(고정지출 불러오기)은 아직 안 끝남
// -> linkAccountScreen으로 진입하되, 수입은 이미 확정돼 있으므로 다시 묻지 않고
// fixedList에 바로 "정기 수입" 항목으로 보여준다(수입 확인 박스는 안 뜸) ----
{
  const bridge = baseBridge({
    getIncomeCheckStatus: () => "regular",
    isIncomeConfirmed: () => true,
    isAccountLinkOnboardingDone: () => false,
    getBudget: () => JSON.stringify({
      income: 2450000,
      fixed_expenses: [{ name: "넷플릭스", amount: 13500, source: "linked" }],
      purchases: [],
      summary: { fixed_total: 13500, spent_total: 0, remaining: 2436500 },
    }),
  });
  const { elements, visible } = runScenario("6) 수입확정 됐지만 계좌연동 전 -> linkAccountScreen(수입 재확인 없음)", bridge);
  assertEqual(visible, ["linkAccountScreen"], "고정지출 불러오기 화면으로 진입");
  assertEqual(elements.incomeStepBox.style.display, "none", "이미 확정된 수입은 다시 묻지 않음(확인 박스 숨김)");
  assertEqual(elements.fixedList.innerHTML.includes("넷플릭스"), true, "기존 고정지출(getBudget 결과)이 목록에 미리 채워짐");
  assertEqual(elements.fixedList.innerHTML.includes("정기 수입") && elements.fixedList.innerHTML.includes("2,450,000원"), true, "확정된 정기 수입이 목록에 항목으로 바로 표시됨");
  assertEqual(elements.linkAccountContinueBtn.innerText, "계속하기", "계좌연동 자체는 아직 안 끝났으므로 버튼 문구는 '계속하기'");
}

// ---- 시나리오 7: "계좌 연동" 버튼 클릭 -> insufficient_data -> 막지 않고
// 화면 안에서 바로 직접 입력 경로를 열어줌 ----
{
  const bridge = baseBridge({
    analyzeIncomePattern: () =>
      JSON.stringify({ status: "insufficient_data", monthly_amount: null, pay_day: null, reason: "최근 1개월치 입금 내역만 확인돼 판단하기엔 데이터가 부족함(최소 2개월 필요)" }),
  });
  const { elements, sandbox } = runScenario("7) 계좌 연동 클릭, insufficient_data 판정", bridge);
  sandbox.linkAccount();
  assertEqual(elements.manualIncomeBox.style.display, "block", "직접 입력 박스가 열림");
  assertEqual(elements.reanalyzeIncomeBtn.style.display, "inline-block", "다시 확인하기 버튼이 노출됨");
}

// ---- 시나리오 8: 고정지출 분류까지 끝난 뒤 "맞아요" 클릭 -> confirmIncome(감지된 금액)
// 호출, 화면은 그대로 linkAccountScreen에 머물고 수입 확인 박스만 사라지며 fixedList에
// 정기 수입이 반영됨(이번엔 감지된 고정지출이 없다고 가정해 수입만 확인) ----
{
  let confirmedAmount = null;
  const bridge = baseBridge({
    analyzeIncomePattern: () =>
      JSON.stringify({ status: "regular", monthly_amount: 2450000, pay_day: 25, reason: "regular reason" }),
    confirmIncome: (amount) => { confirmedAmount = amount; return "{}"; },
  });
  const { elements, sandbox } = runScenario("8) '선택한 항목 추가하기' 클릭 -> 화면 안에서 바로 확정", bridge);
  sandbox.linkAccount();
  sandbox.onFixedExpensesClassified([], false);
  sandbox.commitDetectedCandidates(); // 체크박스는 기본 전부 체크된 상태이므로 그대로 확정됨
  const visibleAfter = SCREEN_IDS.filter((id) => sandbox.document.getElementById(id).style.display !== "none");
  assertEqual(confirmedAmount, 2450000, "AI가 감지한 금액(2,450,000원) 그대로 confirmIncome() 호출됨");
  assertEqual(visibleAfter, ["linkAccountScreen"], "화면 전환 없이 계좌연동 화면에 그대로 머무름(다음 단계 화면이 따로 없음)");
  assertEqual(elements.incomeStepBox.style.display, "none", "확정 후 수입 확인 박스는 사라짐");
  assertEqual(elements.fixedList.innerHTML.includes("정기 수입") && elements.fixedList.innerHTML.includes("2,450,000원"), true, "확정된 수입이 고정지출 목록에 항목으로 반영됨");
}

// ---- 시나리오 9: 정기 수입과 고정지출 후보 둘 다 체크를 해제하고 "선택한 항목
// 추가하기" -> 체크 해제한 항목은 자동 추가되지 않는다. 정기 수입 체크가 풀려서
// 확정되지 않았으므로, 하드컷 판정을 겸하는 단계라 대신 직접 입력 칸이 열리고,
// 그 칸에 입력한 금액으로 confirmIncome()이 호출된다(AI 감지값이 아님) ----
{
  let confirmedAmount = null;
  const bridge = baseBridge({
    analyzeIncomePattern: () =>
      JSON.stringify({ status: "regular", monthly_amount: 2450000, pay_day: 25, reason: "regular reason" }),
    confirmIncome: (amount) => { confirmedAmount = amount; return "{}"; },
  });
  const { elements, sandbox } = runScenario("9) 오탐지 정정: 체크 해제 후 직접 입력으로 전환", bridge);
  sandbox.linkAccount();
  sandbox.onFixedExpensesClassified([{ name: "넷플릭스", amount: 13500 }], true);
  sandbox.toggleDetectedCandidate(0); // 정기 수입 체크 해제(index 0)
  sandbox.toggleDetectedCandidate(1); // 넷플릭스 체크 해제(index 1)
  sandbox.commitDetectedCandidates();
  assertEqual(sandbox.document.getElementById("manualIncomeBox").style.display, "block", "정기 수입 체크를 해제해 확정되지 않았으므로 직접 입력 칸이 대신 열림");
  assertEqual(elements.fixedList.innerHTML.includes("넷플릭스"), false, "체크 해제한 고정지출은 자동으로 추가되지 않음");
  sandbox.document.getElementById("manualIncome").value = "3000000";
  sandbox.confirmManualIncome();
  assertEqual(confirmedAmount, 3000000, "사용자가 직접 입력한 금액(3,000,000원)으로 confirmIncome() 호출됨(AI 감지값이 아님)");
}

// ---- 시나리오 10: 정기 수입을 아직 확정하지 않은 채(계좌 연동도 안 누른 채) "계속하기"를
// 누르면 안내만 뜨고 setup()이 호출되지 않는다 — 정기 수입 확정은 하드컷 판정을 겸하는
// 단계라 건너뛸 수 없다 ----
{
  let setupCalled = false;
  const bridge = baseBridge({
    setup: () => { setupCalled = true; return "{}"; },
  });
  const { sandbox } = runScenario("10) 수입 미확정 상태에서 '계속하기' -> 막힘", bridge);
  sandbox.finishAccountLinking();
  assertEqual(setupCalled, false, "정기 수입 확정 전에는 setup()이 호출되지 않음");
  assertEqual(sandbox.__lastAlert, "정기 수입을 먼저 확인해주세요.", "안내 문구(alert)가 대신 뜸");
}

// ---- 시나리오 11: 계좌연동 -> 수입 확정("맞아요") -> "계속하기" -> 정기 수입과 고정지출
// 목록을 setup()에 넘기고, 계좌연동 온보딩을 완료 처리한 뒤 메인 앱으로 넘어감 ----
{
  let setupPayload = null;
  let markedAccountLinkDone = false;
  const bridge = baseBridge({
    analyzeIncomePattern: () =>
      JSON.stringify({ status: "regular", monthly_amount: 2450000, pay_day: 25, reason: "regular reason" }),
    setup: (json) => {
      setupPayload = JSON.parse(json);
      return JSON.stringify({ income: setupPayload.income, fixed_expenses: setupPayload.fixed_expenses, purchases: [], summary: { fixed_total: 0, spent_total: 0, remaining: setupPayload.income } });
    },
    markAccountLinkOnboardingDone: () => { markedAccountLinkDone = true; },
  });
  const { sandbox } = runScenario("11) 계좌연동 -> 수입확정 -> 계속하기 -> 메인 앱", bridge);
  sandbox.linkAccount();
  sandbox.onFixedExpensesClassified([], false); // 감지된 고정지출은 없다고 가정, 수입만 확인
  sandbox.commitDetectedCandidates();
  sandbox.document.getElementById("fixedName").value = "스타벅스 정기결제";
  sandbox.document.getElementById("fixedAmount").value = "6300";
  sandbox.addFixedRow();
  sandbox.finishAccountLinking();
  const visibleAfter = SCREEN_IDS.filter((id) => sandbox.document.getElementById(id).style.display !== "none");
  assertEqual(setupPayload.income, 2450000, "확정한 정기 수입이 setup() 호출에 그대로 쓰임");
  assertEqual(setupPayload.fixed_expenses, [{ name: "스타벅스 정기결제", amount: 6300, source: "manual" }], "직접 추가한 고정지출이 setup()에 반영됨");
  assertEqual(markedAccountLinkDone, true, "markAccountLinkOnboardingDone()이 호출되어 다음부터는 이 화면부터 시작하지 않음");
  assertEqual(visibleAfter, ["mainApp"], "계좌연동을 마치면 메인 앱으로 전환됨");
}

// ---- 시나리오 12: 메인 앱 대시보드에는 "고정 수입·지출" 요약 카드 + "수정하기" 버튼이
// 더 이상 없음(그 화면(수입·지출을 기입하는 linkAccountScreen)으로 가는 길은 화면 안
// 버튼이 아니라 기기 뒤로가기 버튼 하나로 통일했다) — 카드가 없어도 "이번 달 남은
// 여유" 계산 자체는 정상 동작한다 ----
{
  const bridge = baseBridge({
    getIncomeCheckStatus: () => "regular",
    isIncomeConfirmed: () => true,
    isAccountLinkOnboardingDone: () => true,
    getBudget: () => JSON.stringify({
      income: 2450000,
      fixed_expenses: [
        { name: "넷플릭스", amount: 13500, source: "linked" },
        { name: "헬스장", amount: 49000, source: "manual" },
      ],
      purchases: [],
      summary: { fixed_total: 62500, spent_total: 0, remaining: 2387500 },
    }),
  });
  const { elements } = runScenario("12) 메인 앱: 고정 수입·지출 요약 카드 없음(뒤로가기로만 이동)", bridge);
  assertEqual("mainIncomeSummary" in elements, false, "정기 수입 요약 카드가 index.html에서 더 이상 존재하지 않음");
  assertEqual("mainFixedSummary" in elements, false, "고정지출 요약 카드가 index.html에서 더 이상 존재하지 않음");
  assertEqual(elements.remaining.innerText, "2,387,500원", "요약 카드 없이도 '이번 달 남은 여유'는 정상적으로 계산됨");
}

// ---- 시나리오 13: 메인 앱에서 기기 뒤로가기 -> handleAndroidBack()이 true를 돌려줘서
// (MainActivity.onBackPressed()가 이 값을 보고 앱을 종료하지 않는다) linkAccountScreen이
// "수정 모드"로 열린다. 이 화면 자체가 이미 "뒤로 돌아온" 상태이므로, 버튼은 온보딩
// 때와 똑같이 "계속하기"다(안에 또 "뒤로가기" 버튼을 두면 헷갈리기 때문에 문구를
// 바꾸지 않는다 — 저장/취소를 나누는 두 버튼이 아니라 버튼 하나를 그대로
// 재사용하며, 정기 수입은 다시 묻지 않는다). 이어서 그 화면에서 다시 한번 뒤로가기를
// 누르면 이번엔 false를 돌려줘서 안드로이드 기본 동작(앱 종료)에 맡긴다 ----
{
  const bridge = baseBridge({
    getIncomeCheckStatus: () => "regular",
    isIncomeConfirmed: () => true,
    isAccountLinkOnboardingDone: () => true,
    getBudget: () => JSON.stringify({
      income: 2450000,
      fixed_expenses: [{ name: "넷플릭스", amount: 13500, source: "linked" }],
      purchases: [],
      summary: { fixed_total: 13500, spent_total: 0, remaining: 2436500 },
    }),
  });
  const { elements, sandbox } = runScenario("13) 메인 앱에서 기기 뒤로가기 -> 수정 모드로 전환", bridge);
  const handled = sandbox.handleAndroidBack();
  assertEqual(handled, true, "뒤로가기를 화면 전환으로 처리했다고 안드로이드 쪽에 true를 돌려줌(앱 종료를 막음)");
  const visibleAfter = SCREEN_IDS.filter((id) => sandbox.document.getElementById(id).style.display !== "none");
  assertEqual(visibleAfter, ["linkAccountScreen"], "linkAccountScreen으로 전환됨");
  assertEqual(elements.incomeStepBox.style.display, "none", "수정 모드에서는 수입 확인 박스가 뜨지 않음(재판정하지 않음)");
  assertEqual(elements.fixedList.innerHTML.includes("정기 수입") && elements.fixedList.innerHTML.includes("2,450,000원"), true, "기존 정기 수입이 목록 맨 위에 그대로 표시됨(입력칸 없이)");
  assertEqual(elements.linkAccountContinueBtn.innerText, "계속하기", "이 화면 자체가 이미 '뒤로 돌아온' 상태라, 수정 모드에서도 버튼 문구는 그대로 '계속하기'(뒤로가기 문구로 안 바뀜)");
  assertEqual(elements.linkAccountContinueBtn.className, "save-btn", "버튼 색도 그대로 save-btn(뒤로가기용 스타일로 안 바뀜)");

  const handledAgain = sandbox.handleAndroidBack();
  assertEqual(handledAgain, false, "linkAccountScreen에서는 뒤로가기를 처리하지 않고 안드로이드 기본 동작(앱 종료)에 맡김");
}

// ---- 시나리오 14: 수정 모드에서 고정지출을 새로 추가하고 "계속하기" -> setup()에
// 추가된 고정지출이 반영되고, 이 화면에서 건드리지 않은 정기 수입은 그대로 유지됨 ----
{
  let setupPayload = null;
  const bridge = baseBridge({
    getIncomeCheckStatus: () => "regular",
    isIncomeConfirmed: () => true,
    isAccountLinkOnboardingDone: () => true,
    getBudget: () => JSON.stringify({
      income: 2450000,
      fixed_expenses: [{ name: "넷플릭스", amount: 13500, source: "linked" }],
      purchases: [],
      summary: { fixed_total: 13500, spent_total: 0, remaining: 2436500 },
    }),
    setup: (json) => {
      setupPayload = JSON.parse(json);
      return JSON.stringify({ income: setupPayload.income, fixed_expenses: setupPayload.fixed_expenses, purchases: [], summary: { fixed_total: 13500, spent_total: 0, remaining: 2436500 } });
    },
  });
  const { sandbox } = runScenario("14) 수정 모드: 고정지출 추가 후 계속하기", bridge);
  sandbox.showLinkAccountScreen();
  sandbox.document.getElementById("fixedName").value = "스타벅스 정기결제";
  sandbox.document.getElementById("fixedAmount").value = "6300";
  sandbox.addFixedRow();
  sandbox.finishAccountLinking();
  assertEqual(
    setupPayload.fixed_expenses,
    [
      { name: "넷플릭스", amount: 13500, source: "linked" },
      { name: "스타벅스 정기결제", amount: 6300, source: "manual" },
    ],
    "새로 추가한 고정지출까지 포함해서 setup()에 반영됨"
  );
  assertEqual(setupPayload.income, 2450000, "정기 수입은 이 화면에서 건드리지 않았으므로 그대로 유지됨");
}

// ---- 시나리오 15: 수정 모드에서 기존 고정지출을 삭제하고 "계속하기" -> setup()에
// 삭제가 반영됨(정기 수입은 여전히 그대로 유지) ----
{
  let setupPayload = null;
  const bridge = baseBridge({
    getIncomeCheckStatus: () => "regular",
    isIncomeConfirmed: () => true,
    isAccountLinkOnboardingDone: () => true,
    getBudget: () => JSON.stringify({
      income: 2450000,
      fixed_expenses: [
        { name: "넷플릭스", amount: 13500, source: "linked" },
        { name: "헬스장 정기결제", amount: 49000, source: "linked" },
      ],
      purchases: [],
      summary: { fixed_total: 62500, spent_total: 0, remaining: 2387500 },
    }),
    setup: (json) => {
      setupPayload = JSON.parse(json);
      return JSON.stringify({ income: setupPayload.income, fixed_expenses: setupPayload.fixed_expenses, purchases: [], summary: { fixed_total: 49000, spent_total: 0, remaining: 2401000 } });
    },
  });
  const { sandbox } = runScenario("15) 수정 모드: 고정지출 삭제 후 계속하기", bridge);
  sandbox.showLinkAccountScreen();
  // 목록 맨 위(0번)는 이제 "정기 수입" 항목이므로, 넷플릭스는 1번 인덱스다
  // (수입도 같은 목록에 같은 방식으로 들어가면서 생긴 순서 변화).
  sandbox.removeFixedRow(1); // 넷플릭스 삭제
  sandbox.finishAccountLinking();
  assertEqual(setupPayload.fixed_expenses, [{ name: "헬스장 정기결제", amount: 49000, source: "linked" }], "삭제한 항목이 빠진 채로 setup()에 반영됨");
  assertEqual(setupPayload.income, 2450000, "정기 수입은 이 화면에서 건드리지 않았으므로 그대로 유지됨");
}

// ---- 시나리오 16: 앱을 맨 처음 시작 -> 권한 팝업은 "화면"이 아니라 그 뒤에 이미 떠 있는
// 화면(여기서는 계좌연동) 위에 겹쳐서 뜬다. 화면 전환(routeToScreen)과 권한 팝업 표시는
// 서로 독립적으로 처리된다는 게 이번 구조의 핵심이라, 이 부분을 명시적으로 검증한다. ----
{
  const bridge = baseBridge({
    isPermissionOnboardingDone: () => false,
    isAccessibilityServiceEnabled: () => false,
    isOverlayPermissionGranted: () => false,
  });
  const { visible, modalOpen } = runScenario("16) 최초 실행 -> 계좌연동 화면 위에 권한 팝업이 겹쳐 뜸", bridge);
  assertEqual(visible, ["linkAccountScreen"], "뒤에 있는 화면은 그대로 계좌연동 화면(화면 전환 로직은 권한과 무관)");
  assertEqual(modalOpen, true, "권한 온보딩이 안 끝났으므로 팝업이 그 위에 떠 있음");
}

// ---- 시나리오 17: "권한 확인하고 계속하기" 클릭 -> 둘 다 꺼져 있으면 안내만 뜨고 팝업은 안 닫힘 ----
{
  let markedDone = false;
  const bridge = baseBridge({
    isPermissionOnboardingDone: () => false,
    isAccessibilityServiceEnabled: () => false,
    isOverlayPermissionGranted: () => false,
    markPermissionOnboardingDone: () => { markedDone = true; },
  });
  const { elements, sandbox } = runScenario("17) 권한 미허용 상태에서 계속하기 클릭", bridge);
  sandbox.tryClosePermissionModal();
  assertEqual(elements.permissionCheckMsg.style.display, "block", "둘 다 켜야 한다는 안내가 표시됨");
  assertEqual(markedDone, false, "권한 온보딩이 완료 처리되지 않음");
  assertEqual(elements.permissionModal.style.display, "flex", "팝업이 닫히지 않고 그대로 떠 있음");
}

// ---- 시나리오 18: 하나만 켜진 상태에서 클릭 -> 여전히 통과하지 못함 ----
{
  const bridge = baseBridge({
    isPermissionOnboardingDone: () => false,
    isAccessibilityServiceEnabled: () => true,
    isOverlayPermissionGranted: () => false, // 오버레이 권한만 아직 꺼져 있음
    markPermissionOnboardingDone: () => { throw new Error("한쪽만 켜졌는데 완료 처리되면 안 됨"); },
  });
  const { elements, sandbox } = runScenario("18) 한쪽만 허용된 상태에서 계속하기 클릭", bridge);
  sandbox.tryClosePermissionModal();
  assertEqual(elements.permissionCheckMsg.style.display, "block", "여전히 안내가 표시됨(하나는 꺼져 있음)");
  assertEqual(elements.permissionModal.style.display, "flex", "팝업이 여전히 떠 있음");
}

// ---- 시나리오 19: 둘 다 켜진 뒤 클릭 -> 완료 처리되고 팝업만 닫히며, 뒤에 있던
// 계좌연동 화면은 다시 보여줄 필요 없이 이미 그대로 떠 있다(화면 자체는 팝업과
// 무관하게 계속 유지돼 있었음) ----
{
  let markedDone = false;
  const bridge = baseBridge({
    isPermissionOnboardingDone: () => false,
    isAccessibilityServiceEnabled: () => true,
    isOverlayPermissionGranted: () => true,
    markPermissionOnboardingDone: () => { markedDone = true; bridge.isPermissionOnboardingDone = () => true; },
  });
  const { elements, sandbox } = runScenario("19) 둘 다 허용 후 계속하기 클릭 -> 팝업만 닫힘", bridge);
  sandbox.tryClosePermissionModal();
  assertEqual(markedDone, true, "markPermissionOnboardingDone()이 호출됨");
  assertEqual(elements.permissionModal.style.display, "none", "권한 팝업이 닫힘");
  assertEqual(elements.linkAccountScreen.style.display, "block", "뒤에 있던 계좌연동 화면은 그대로 유지돼 있음(재실행 불필요)");
}

// ---- 시나리오 20: "+ 직접 추가" 위의 지출/수입 토글 -> 기본값은 "지출"이고, "수입"을
// 클릭한 뒤 추가하면 type:"income"으로 목록에 들어가며 "수입" 배지가 붙는다.
// (예전엔 고정지출만 직접 추가할 수 있었는데, 이제 수입도 같은 방식으로 추가 가능) ----
{
  const bridge = baseBridge({});
  const { elements, sandbox } = runScenario("20) 직접 추가: 지출/수입 토글로 수입 항목 추가", bridge);
  assertEqual(elements.typeExpenseBtn.className, "type-toggle-btn active", "화면 진입 시 토글 기본값은 '지출'");
  sandbox.setAddType("income");
  assertEqual(elements.typeIncomeBtn.className, "type-toggle-btn active", "'수입' 토글을 누르면 활성 표시가 옮겨감");
  assertEqual(elements.typeExpenseBtn.className, "type-toggle-btn", "'지출' 토글은 비활성으로 바뀜");
  sandbox.document.getElementById("fixedName").value = "용돈";
  sandbox.document.getElementById("fixedAmount").value = "200000";
  sandbox.addFixedRow();
  assertEqual(
    elements.fixedList.innerHTML.includes("용돈") && elements.fixedList.innerHTML.includes('class="badge income"'),
    true,
    "수입으로 추가한 항목이 '수입' 배지와 함께 목록에 표시됨"
  );
}

// ---- 시나리오 21: 계좌 연동으로 정기 수입이 이미 확정된 상태에서, 사용자가 "직접
// 추가"로 부수입 등 수입 항목을 추가로 넣으면 두 수입이 합산되어 setup()에는 하나의
// income 합계로 전달된다(백엔드는 수입을 여전히 숫자 하나로만 받으므로) ----
{
  let setupPayload = null;
  const bridge = baseBridge({
    getIncomeCheckStatus: () => "regular",
    isIncomeConfirmed: () => true,
    isAccountLinkOnboardingDone: () => true,
    getBudget: () => JSON.stringify({
      income: 2450000,
      fixed_expenses: [{ name: "넷플릭스", amount: 13500, source: "linked" }],
      purchases: [],
      summary: { fixed_total: 13500, spent_total: 0, remaining: 2436500 },
    }),
    setup: (json) => {
      setupPayload = JSON.parse(json);
      return JSON.stringify({ income: setupPayload.income, fixed_expenses: setupPayload.fixed_expenses, purchases: [], summary: { fixed_total: 13500, spent_total: 0, remaining: setupPayload.income } });
    },
  });
  const { sandbox } = runScenario("21) 수정 모드: 부수입을 직접 추가 -> 정기 수입과 합산돼 저장됨", bridge);
  sandbox.showLinkAccountScreen();
  sandbox.setAddType("income");
  sandbox.document.getElementById("fixedName").value = "부수입(과외)";
  sandbox.document.getElementById("fixedAmount").value = "300000";
  sandbox.addFixedRow();
  sandbox.finishAccountLinking();
  assertEqual(setupPayload.income, 2750000, "기존 정기 수입(2,450,000)과 새로 추가한 부수입(300,000)이 합산돼 저장됨");
  assertEqual(
    setupPayload.fixed_expenses,
    [{ name: "넷플릭스", amount: 13500, source: "linked" }],
    "수입 항목은 지출 목록에 섞이지 않고 따로 합산됨"
  );
}

// ---- 시나리오 22: 정기 수입 판정(regular)과 고정지출 자동 분류 결과를 체크박스
// 목록 한 카드에서 함께 확인한다(기본은 전부 체크됨). 한 번에 전부 확정/거절하는
// 게 아니라, 그중 하나(헬스장)만 오탐지라고 판단해 체크를 해제하면 그 항목만
// 빠지고 나머지(정기 수입 + 넷플릭스)는 "선택한 항목 추가하기"로 그대로 반영된다
// — "체크표시를 해제하듯이 잘못된 것만 뺀다"는 요구의 핵심 시나리오 ----
{
  let confirmedAmount = null;
  const bridge = baseBridge({
    analyzeIncomePattern: () =>
      JSON.stringify({ status: "regular", monthly_amount: 2450000, pay_day: 25, reason: "regular reason" }),
    confirmIncome: (amount) => { confirmedAmount = amount; return "{}"; },
  });
  const { elements, sandbox } = runScenario("22) 체크박스 목록에서 오탐지 항목 하나만 체크 해제", bridge);
  sandbox.linkAccount();
  sandbox.onFixedExpensesClassified(
    [
      { name: "넷플릭스", amount: 13500 },
      { name: "헬스장 정기결제", amount: 49000 },
    ],
    true
  );
  assertEqual(elements.incomeConfirmBox.style.display, "block", "정기 수입+고정지출 확인 카드가 함께 표시됨");
  assertEqual(
    elements.detectedCandidatesList.innerHTML.includes("정기 수입") &&
      elements.detectedCandidatesList.innerHTML.includes("넷플릭스") &&
      elements.detectedCandidatesList.innerHTML.includes("헬스장"),
    true,
    "정기 수입과 감지된 고정지출 후보들이 체크박스 목록에 함께 나열됨(기본 전부 체크)"
  );
  assertEqual(elements.fixedList.innerHTML.includes("넷플릭스"), false, "확인 전에는 예전처럼 자동으로 추가되지 않음");

  // 후보 순서: 0=정기 수입, 1=넷플릭스, 2=헬스장 정기결제. "헬스장 정기결제"만
  // 잘못 감지됐다고 보고 그 항목의 체크만 해제한다.
  sandbox.toggleDetectedCandidate(2);
  sandbox.commitDetectedCandidates();
  assertEqual(confirmedAmount, 2450000, "체크가 남아 있던 정기 수입은 그대로 확정됨");
  assertEqual(
    elements.fixedList.innerHTML.includes("정기 수입") && elements.fixedList.innerHTML.includes("넷플릭스"),
    true,
    "체크가 남아 있던 정기 수입과 넷플릭스는 목록에 반영됨"
  );
  assertEqual(elements.fixedList.innerHTML.includes("헬스장"), false, "체크를 해제한 헬스장 정기결제만 쏙 빠지고 추가되지 않음");
  assertEqual(elements.incomeStepBox.style.display, "none", "체크된 항목 확인이 끝나면 확인 단계 박스가 닫힘");
}

// ---- 시나리오 23: 감지된 고정지출(넷플릭스)은 체크를 유지한 채 정기 수입 체크만
// 해제하면, 정기 수입은 따로 직접 입력하게 되고 고정지출은 그와 별개로 곧바로
// 목록에 반영된다 — 항목마다 독립적으로 체크를 켜고 끌 수 있어야 한다는 요구를
// 검증한다(정기 수입이 틀렸다고 고정지출까지 덩달아 버려지지 않음) ----
{
  const bridge = baseBridge({
    analyzeIncomePattern: () =>
      JSON.stringify({ status: "regular", monthly_amount: 2450000, pay_day: 25, reason: "regular reason" }),
  });
  const { elements, sandbox } = runScenario("23) 정기 수입만 체크 해제 -> 고정지출은 그대로 반영됨", bridge);
  sandbox.linkAccount();
  sandbox.onFixedExpensesClassified([{ name: "넷플릭스", amount: 13500 }], true);
  sandbox.toggleDetectedCandidate(0); // 정기 수입만 체크 해제(index 0), 넷플릭스는 그대로 둠
  sandbox.commitDetectedCandidates();
  assertEqual(elements.manualIncomeBox.style.display, "block", "정기 수입 체크를 해제했으므로 직접 입력 칸이 대신 열림");
  assertEqual(elements.fixedList.innerHTML.includes("넷플릭스"), true, "체크가 남아 있던 고정지출은 정기 수입과 무관하게 그대로 목록에 반영됨");
}

// ---- 시나리오 24: 수정 모드(정기 수입은 이미 확정됨)에서 "계좌 연동"을 다시 눌러도,
// 새로 감지된 고정지출은 예전처럼 곧장 추가되지 않고 정기 수입 때와 똑같은 확인
// 카드(이 경우 수입 줄 없이 고정지출만)를 거쳐야 한다 — 이미 목록에 있는 항목은
// 후보에서 제외되고, 새로 발견된 것만 확인 대상이 된다 ----
{
  let setupPayload = null;
  const bridge = baseBridge({
    getIncomeCheckStatus: () => "regular",
    isIncomeConfirmed: () => true,
    isAccountLinkOnboardingDone: () => true,
    getBudget: () => JSON.stringify({
      income: 2450000,
      fixed_expenses: [{ name: "넷플릭스", amount: 13500, source: "linked" }],
      purchases: [],
      summary: { fixed_total: 13500, spent_total: 0, remaining: 2436500 },
    }),
    setup: (json) => {
      setupPayload = JSON.parse(json);
      return JSON.stringify({ income: setupPayload.income, fixed_expenses: setupPayload.fixed_expenses, purchases: [], summary: { fixed_total: 0, spent_total: 0, remaining: setupPayload.income } });
    },
  });
  const { elements, sandbox } = runScenario("24) 수정 모드 재연동: 새로 감지된 고정지출도 확인 필요(자동추가 안 됨)", bridge);
  sandbox.showLinkAccountScreen();
  sandbox.linkAccount();
  sandbox.onFixedExpensesClassified(
    [
      { name: "넷플릭스", amount: 13500 }, // 이미 목록에 있어서 후보에서 제외됨
      { name: "왓챠", amount: 9900 },
    ],
    true
  );
  assertEqual(elements.incomeConfirmBox.style.display, "block", "이미 확정된 수입 없이 새로 감지된 고정지출만 확인 카드로 뜸");
  assertEqual(elements.detectedCandidatesList.innerHTML.includes("정기 수입"), false, "수입은 이미 확정돼 있으므로 이 카드에 정기 수입 후보는 안 보임");
  assertEqual(
    elements.detectedCandidatesList.innerHTML.includes("왓챠") && !elements.detectedCandidatesList.innerHTML.includes("넷플릭스"),
    true,
    "이미 목록에 있는 넷플릭스는 후보에서 빠지고 새로 발견된 왓챠만 뜸"
  );
  assertEqual(elements.fixedList.innerHTML.includes("왓챠"), false, "확인 전에는 새 항목이 아직 목록에 추가되지 않음");

  sandbox.commitDetectedCandidates();
  sandbox.finishAccountLinking();
  assertEqual(
    setupPayload.fixed_expenses,
    [
      { name: "넷플릭스", amount: 13500, source: "linked" },
      { name: "왓챠", amount: 9900, source: "ai-linked" },
    ],
    "확인을 거친 새 고정지출만 저장에 반영됨"
  );
}

console.log("");
if (failures > 0) {
  console.error(`${failures}개 검증 실패`);
  process.exit(1);
} else {
  console.log("모든 프론트엔드 플로우 검증 통과");
}
