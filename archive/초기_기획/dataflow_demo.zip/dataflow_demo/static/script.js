// ---- 1) 화면이 열리자마자: JSON 파일 -> Flask -> 화면 으로 데이터 가져오기 ----
async function loadCheckins() {
  const res = await fetch("/api/checkins"); // GET 요청
  if (!res.ok) {
    document.getElementById("result").innerText = "불러오기 실패";
    return;
  }
  const items = await res.json(); // 서버가 보내준 JSON을 JS 객체로 변환
  renderCheckins(items);
}

// ---- 2) 받아온 데이터를 실제 화면(DOM)에 그려주는 함수 ----
function renderCheckins(items) {
  const container = document.getElementById("result");

  if (!items || items.length === 0) {
    container.innerText = "아직 등록된 체크인이 없습니다.";
    return;
  }

  container.innerHTML = items
    .map(
      (item) => `
      <div class="card">
        <strong>${item.name}</strong> (${item.week})
        <p>✅ 한 일: ${item.done}</p>
        <p>📌 다음 계획: ${item.next}</p>
      </div>
    `
    )
    .join("");
}

// ---- 3) 화면(입력폼) -> Flask -> JSON 파일 로 데이터 보내기 ----
async function submitCheckin() {
  const payload = {
    name: document.getElementById("name").value,
    week: document.getElementById("week").value,
    done: document.getElementById("done").value,
    next: document.getElementById("next").value,
  };

  const res = await fetch("/api/checkins", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });

  if (!res.ok) {
    alert("등록에 실패했습니다. 이름을 입력했는지 확인해주세요.");
    return;
  }

  const items = await res.json(); // 서버가 저장 후 돌려준 최신 전체 목록
  renderCheckins(items); // 화면을 새로고침 없이 즉시 갱신

  // 입력창 비우기
  document.getElementById("name").value = "";
  document.getElementById("week").value = "";
  document.getElementById("done").value = "";
  document.getElementById("next").value = "";
}

// 페이지가 열리자마자 1번 함수 실행
loadCheckins();
