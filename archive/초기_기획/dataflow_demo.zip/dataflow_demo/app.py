from flask import Flask, request, jsonify, render_template
import json
import os

app = Flask(__name__)

DATA_PATH = os.path.join(os.path.dirname(__file__), "data", "checkins.json")


def load_checkins():
    """JSON 파일을 읽어서 파이썬 리스트로 반환한다."""
    with open(DATA_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


def save_checkins(items):
    """파이썬 리스트를 JSON 파일에 저장한다. (한글 깨짐 방지)"""
    with open(DATA_PATH, "w", encoding="utf-8") as f:
        json.dump(items, f, ensure_ascii=False, indent=2)


@app.route("/")
def home():
    # 화면(HTML) 자체는 Flask가 templates/index.html을 그대로 띄워준다.
    # 데이터는 이 HTML 안의 JavaScript가 /api/checkins 를 호출해서 따로 가져온다.
    return render_template("index.html")


@app.route("/api/checkins", methods=["GET"])
def get_checkins():
    """프론트엔드가 fetch()로 호출하는 조회용 API. JSON 파일 -> JSON 응답."""
    items = load_checkins()
    return jsonify(items)


@app.route("/api/checkins", methods=["POST"])
def add_checkin():
    """프론트엔드 폼에서 입력한 내용을 받아 JSON 파일에 새로 추가한다."""
    data = request.get_json()

    name = data.get("name", "").strip()
    week = data.get("week", "").strip()
    done = data.get("done", "").strip()
    next_plan = data.get("next", "").strip()

    if not name:
        return jsonify({"error": "이름은 필수입니다."}), 400

    items = load_checkins()
    new_id = (max([item["id"] for item in items]) + 1) if items else 1

    new_item = {
        "id": new_id,
        "name": name,
        "week": week,
        "done": done,
        "next": next_plan,
    }
    items.append(new_item)
    save_checkins(items)

    # 저장 후 전체 최신 목록을 다시 돌려줘서 화면이 바로 갱신되게 한다.
    return jsonify(items), 201


if __name__ == "__main__":
    # debug=True는 개발용. 발표·배포 시에는 꺼야 한다.
    app.run(debug=True)
