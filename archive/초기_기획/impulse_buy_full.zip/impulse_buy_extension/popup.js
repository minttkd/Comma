const toggle = document.getElementById("enabledToggle");
const remainingEl = document.getElementById("remaining");
const openSetupBtn = document.getElementById("openSetupBtn");

const won = (n) => Number(n).toLocaleString("ko-KR") + "원";

// 저장된 on/off 상태 불러오기 (기본값: 켜짐)
chrome.storage.local.get(["enabled"], (result) => {
  toggle.checked = result.enabled !== false;
});

toggle.addEventListener("change", () => {
  chrome.storage.local.set({ enabled: toggle.checked });
});

openSetupBtn.addEventListener("click", () => {
  chrome.tabs.create({ url: "http://127.0.0.1:5000/" });
});

chrome.runtime.sendMessage({ type: "GET_BUDGET" }, (response) => {
  if (!response || response.error) {
    remainingEl.innerText = "서버 연결 안 됨";
    return;
  }
  remainingEl.innerText = won(response.result.summary.remaining);
});
