// ---- "이거 사도 될까?" 확장 프로그램: 아무 사이트에서나 결제 버튼 클릭을 가로챈다 ----

const BUY_KEYWORDS = [
  "구매하기", "구매", "바로구매", "바로 구매", "결제하기", "결제",
  "주문하기", "주문", "결제 진행", "구독하기", "구독", "카드결제",
  "buy now", "buy", "checkout", "check out", "pay now", "place order", "purchase",
];

function normalize(text) {
  return (text || "").trim().toLowerCase();
}

function looksLikeBuyButton(el) {
  if (!el) return false;
  const text = normalize(el.innerText || el.value || el.getAttribute("aria-label") || "");
  if (!text || text.length > 14) return false;
  return BUY_KEYWORDS.some((kw) => text === kw || text.includes(kw));
}

function findClickableAncestor(el) {
  let node = el;
  for (let i = 0; i < 5 && node; i++) {
    if (
      node.tagName === "BUTTON" ||
      node.tagName === "A" ||
      (node.tagName === "INPUT" && (node.type === "submit" || node.type === "button")) ||
      node.getAttribute?.("role") === "button"
    ) {
      return node;
    }
    node = node.parentElement;
  }
  return null;
}

// 버튼 주변 텍스트에서 "12,000원" 같은 금액을 찾아 추정한다. 못 찾으면 null.
function guessAmountNearby(target) {
  let container = target;
  for (let i = 0; i < 4 && container; i++) {
    const text = container.innerText || "";
    const match = text.match(/([0-9][0-9,]{2,})\s*원/);
    if (match) {
      const amount = parseInt(match[1].replace(/,/g, ""), 10);
      if (amount > 0) return amount;
    }
    container = container.parentElement;
  }
  return null;
}

function passthroughClick(target) {
  target.dataset.impulseGuardSkip = "1";
  target.click();
  delete target.dataset.impulseGuardSkip;
}

function removeOverlay() {
  const el = document.getElementById("impulse-guard-overlay-backdrop");
  if (el) el.remove();
}

function statusLabel(status) {
  if (status === "safe") return "🟢 여유 있어요";
  if (status === "warning") return "🟡 살 수는 있지만 주의";
  return "🔴 이번 달 여유를 넘어요";
}

function won(n) {
  return Number(n).toLocaleString("ko-KR") + "원";
}

function showOverlay(target, guessedAmount) {
  removeOverlay();

  const backdrop = document.createElement("div");
  backdrop.id = "impulse-guard-overlay-backdrop";
  backdrop.innerHTML = `
    <div id="impulse-guard-card">
      <h3>🛑 이거 사도 될까?</h3>
      <p class="ig-sub">방금 누른 결제 버튼을 잠깐 멈췄어요. 금액을 확인하고 판단해볼게요.</p>
      <div class="ig-amount-row">
        <input id="ig-amount-input" type="number" value="${guessedAmount || ""}" placeholder="금액을 입력하세요 (원)" />
        <span>원</span>
      </div>
      <div id="ig-result" class="ig-result"></div>
      <div class="ig-buttons" id="ig-buttons-check">
        <button class="ig-cancel-btn" id="ig-cancel-btn">취소</button>
        <button class="ig-check-btn" id="ig-check-btn">확인하기</button>
      </div>
    </div>
  `;
  document.body.appendChild(backdrop);

  document.getElementById("ig-cancel-btn").onclick = () => removeOverlay();
  backdrop.addEventListener("click", (e) => {
    if (e.target === backdrop) removeOverlay();
  });

  document.getElementById("ig-check-btn").onclick = async () => {
    const amount = Number(document.getElementById("ig-amount-input").value);
    if (!amount) {
      alert("금액을 입력해주세요.");
      return;
    }

    const resultBox = document.getElementById("ig-result");
    resultBox.className = "ig-result";
    resultBox.style.display = "block";
    resultBox.innerHTML = '<div class="ig-loading">확인하는 중...</div>';

    chrome.runtime.sendMessage({ type: "CHECK_PURCHASE", amount }, (response) => {
      if (!response || response.error) {
        resultBox.innerHTML =
          '<div class="ig-loading">앱 서버에 연결할 수 없어요. (Flask 서버가 켜져 있는지 확인해주세요)</div>';
        return;
      }

      const r = response.result;
      resultBox.className = "ig-result " + r.status;
      resultBox.innerHTML = `
        <strong>${statusLabel(r.status)}</strong>
        <div>${r.message}</div>
        <div class="ig-small">지금 사면 남은 여유: ${won(r.remaining_after)}</div>
      `;

      chrome.runtime.sendMessage({
        type: "SHOW_NOTIFICATION",
        title: statusLabel(r.status),
        message: `${r.message} (남은 여유 ${won(r.remaining_after)})`,
      });

      document.getElementById("ig-buttons-check").innerHTML = `
        <button class="ig-cancel-btn" id="ig-cancel-btn-2">그만두기</button>
        <button class="ig-confirm-btn" id="ig-confirm-btn">그래도 구매하기</button>
      `;
      document.getElementById("ig-cancel-btn-2").onclick = () => removeOverlay();
      document.getElementById("ig-confirm-btn").onclick = () => {
        chrome.runtime.sendMessage({
          type: "CONFIRM_PURCHASE",
          name: document.title.slice(0, 30) || "구매 항목",
          amount,
        });
        removeOverlay();
        passthroughClick(target);
      };
    });
  };
}

// chrome.storage.local.get은 비동기라서, 클릭 이벤트 처리 중에 그 결과를 기다리면
// 그 사이 원래 사이트의 onclick이 이미 동기적으로 실행되어버린다(테스트로 확인된 버그).
// 그래서 on/off 값을 미리 변수에 캐시해두고, 클릭 핸들러 안에서는 동기적으로만 판단한다.
let guardEnabled = true; // 기본값: 켜짐

chrome.storage.local.get(["enabled"], (result) => {
  guardEnabled = result.enabled !== false;
});

chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "local" && "enabled" in changes) {
    guardEnabled = changes.enabled.newValue !== false;
  }
});

function handleClick(e) {
  if (!guardEnabled) return;
  // 우리 자신의 오버레이 UI(예: "그래도 구매하기" 버튼엔 '구매'라는 단어가 들어있다)는
  // 감시 대상에서 완전히 제외한다. 안 그러면 우리 버튼을 우리가 다시 가로채는 무한루프가 생긴다.
  if (e.target.closest && e.target.closest("#impulse-guard-overlay-backdrop")) return;

  const target = findClickableAncestor(e.target);
  if (!target) return;
  if (target.dataset.impulseGuardSkip === "1") return; // 확인 후 통과시킨 클릭
  if (!looksLikeBuyButton(target)) return;

  e.preventDefault();
  e.stopPropagation();
  e.stopImmediatePropagation();

  const amount = guessAmountNearby(target);
  showOverlay(target, amount);
}

document.addEventListener("click", handleClick, true);
