// 우리 Flask 앱 주소. 처음 켤 때 이 서버가 실행 중이어야 한다.
const API_BASE = "http://127.0.0.1:5000";

// content script(웹페이지 안)에서 직접 fetch하면 방문 중인 사이트가 https일 때
// mixed-content(혼합 콘텐츠) 정책으로 막힐 수 있어서, 확장 프로그램 자체 컨텍스트인
// background에서 대신 fetch 해준다.
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "CHECK_PURCHASE") {
    fetch(`${API_BASE}/api/check`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ amount: msg.amount }),
    })
      .then((res) => res.json())
      .then((result) => sendResponse({ result }))
      .catch((err) => sendResponse({ error: String(err) }));
    return true; // 비동기 응답을 위해 필요
  }

  if (msg.type === "CONFIRM_PURCHASE") {
    fetch(`${API_BASE}/api/purchases`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name: msg.name, amount: msg.amount }),
    })
      .then((res) => res.json())
      .then((result) => sendResponse({ result }))
      .catch((err) => sendResponse({ error: String(err) }));
    return true;
  }

  if (msg.type === "GET_BUDGET") {
    fetch(`${API_BASE}/api/budget`)
      .then((res) => res.json())
      .then((result) => sendResponse({ result }))
      .catch((err) => sendResponse({ error: String(err) }));
    return true;
  }

  if (msg.type === "SHOW_NOTIFICATION") {
    chrome.notifications.create({
      type: "basic",
      iconUrl: chrome.runtime.getURL("icons/icon128.png"),
      title: msg.title,
      message: msg.message,
      priority: 2,
    });
  }
});
