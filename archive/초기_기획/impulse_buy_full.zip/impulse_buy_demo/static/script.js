let currentBudget = null;
let localFixedRows = []; // 저장 전 화면에서만 관리하는 고정지출 임시 목록
let pendingCheck = null; // "그래도 구매하기" 버튼을 위해 잠깐 기억해두는 값

const won = (n) => Number(n).toLocaleString("ko-KR") + "원";

// ---- 1) 페이지 로드: JSON 파일 -> Flask -> 화면 ----
async function loadBudget() {
  const res = await fetch("/api/budget");
  const budget = await res.json();
  currentBudget = budget;
  localFixedRows = [...budget.fixed_expenses];

  document.getElementById("income").value = budget.income || "";
  renderSummary(budget.summary);
  renderFixedList();
  renderPurchaseList(budget.purchases);
}

function renderSummary(summary) {
  const remainingEl = document.getElementById("remaining");
  remainingEl.innerText = won(summary.remaining);
  remainingEl.className =
    "summary-amount " + (summary.remaining < 0 ? "danger" : "");
  document.getElementById("summarySub").innerText =
    `고정지출 ${won(summary.fixed_total)} · 이미 쓴 금액 ${won(summary.spent_total)}`;
}

function renderFixedList() {
  const el = document.getElementById("fixedList");
  if (localFixedRows.length === 0) {
    el.innerHTML = '<div class="empty">등록된 고정지출이 없어요.</div>';
    return;
  }
  el.innerHTML = localFixedRows
    .map(
      (item, i) => `
      <div class="fixed-row">
        <span>${item.name}${item.source === "linked" ? '<span class="badge">연동됨</span>' : ""}</span>
        <span>${won(item.amount)}</span>
        <button class="remove-btn" onclick="removeFixedRow(${i})">삭제</button>
      </div>
    `
    )
    .join("");
}

function addFixedRow() {
  const name = document.getElementById("fixedName").value.trim();
  const amount = Number(document.getElementById("fixedAmount").value);
  if (!name || !amount) {
    alert("고정지출 이름과 금액을 입력해주세요.");
    return;
  }
  localFixedRows.push({ name, amount, source: "manual" });
  renderFixedList();
  document.getElementById("fixedName").value = "";
  document.getElementById("fixedAmount").value = "";
}

function removeFixedRow(index) {
  localFixedRows.splice(index, 1);
  renderFixedList();
}

// ---- 사용자가 직접 입력하지 않아도 되도록: 계좌/카드 연동 시뮬레이션 ----
async function linkAccount() {
  const btn = document.getElementById("linkBtn");
  const originalText = btn.innerText;
  btn.disabled = true;
  btn.innerText = "연동 중...";

  try {
    const res = await fetch("/api/linked-subscriptions");
    const data = await res.json();

    let addedCount = 0;
    data.detected_subscriptions.forEach((sub) => {
      const exists = localFixedRows.some((r) => r.name === sub.name);
      if (!exists) {
        localFixedRows.push({ name: sub.name, amount: sub.amount, source: "linked" });
        addedCount++;
      }
    });

    renderFixedList();
    btn.innerText = `✅ ${data.bank_name} 연동 완료 (${addedCount}건 자동 추가)`;
  } catch (e) {
    btn.innerText = "연동 실패, 다시 시도해주세요";
    btn.disabled = false;
    return;
  }

  setTimeout(() => {
    btn.innerText = originalText;
    btn.disabled = false;
  }, 2500);
}

// ---- 2) 화면 -> Flask -> JSON 파일: 초기 설정 저장 ----
async function saveSetup() {
  const income = Number(document.getElementById("income").value);
  const res = await fetch("/api/setup", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ income, fixed_expenses: localFixedRows }),
  });
  const budget = await res.json();
  currentBudget = budget;
  renderSummary(budget.summary);
  alert("설정이 저장됐어요.");
}

// ---- 3) 구매 전 판단: 화면 -> Flask(계산만) -> 화면 ----
async function checkPurchase() {
  const amount = Number(document.getElementById("checkAmount").value);
  if (!amount) {
    alert("금액을 입력해주세요.");
    return;
  }

  const res = await fetch("/api/check", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ amount }),
  });
  const result = await res.json();

  const box = document.getElementById("checkResult");
  box.className = "check-result " + result.status;
  box.innerHTML = `
    <strong>${statusLabel(result.status)}</strong>
    <p>${result.message}</p>
    <p class="small">지금 사면 남은 여유: ${won(result.remaining_after)}</p>
  `;

  pendingCheck = {
    name: document.getElementById("checkName").value.trim() || "구매 항목",
    amount,
  };
  document.getElementById("confirmBtn").style.display = "inline-block";
}

function statusLabel(status) {
  if (status === "safe") return "🟢 여유 있어요";
  if (status === "warning") return "🟡 살 수는 있지만 주의";
  return "🔴 이번 달 여유를 넘어요";
}

// ---- 4) 실제 구매 확정: 화면 -> Flask -> JSON 파일 저장 ----
async function confirmPurchase() {
  if (!pendingCheck) return;

  const res = await fetch("/api/purchases", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(pendingCheck),
  });
  const budget = await res.json();
  currentBudget = budget;

  renderSummary(budget.summary);
  renderPurchaseList(budget.purchases);

  // 입력 초기화
  document.getElementById("checkName").value = "";
  document.getElementById("checkAmount").value = "";
  document.getElementById("checkResult").innerHTML = "";
  document.getElementById("confirmBtn").style.display = "none";
  pendingCheck = null;
}

function renderPurchaseList(purchases) {
  const el = document.getElementById("purchaseList");
  if (!purchases || purchases.length === 0) {
    el.innerText = "아직 구매 기록이 없어요.";
    return;
  }
  el.innerHTML = purchases
    .map((p) => `<div class="purchase-row"><span>${p.name}</span><span>${won(p.amount)}</span></div>`)
    .join("");
}

// ---- 다른 앱에서 '구매하기'를 누른 상황을 시뮬레이션: URL로 넘어온 값을 자동으로 확인 ----
function checkIncomingFromShop() {
  const params = new URLSearchParams(window.location.search);
  const name = params.get("check_name");
  const amount = params.get("check_amount");
  const from = params.get("from");

  if (!name || !amount) return;

  document.getElementById("checkName").value = name;
  document.getElementById("checkAmount").value = amount;

  const banner = document.getElementById("shopBanner");
  if (from) {
    banner.style.display = "block";
    banner.innerText = `🔗 '${from === "mock_shop" ? "이지쇼핑" : from}'에서 결제하려고 해서, 사기 전에 먼저 확인해봤어요.`;
  }

  // 새로고침해도 같은 확인이 반복 실행되지 않도록 URL을 정리
  window.history.replaceState({}, "", "/");

  checkPurchase();
  document.querySelector(".check-box").scrollIntoView({ behavior: "smooth" });
}

loadBudget().then(checkIncomingFromShop);
