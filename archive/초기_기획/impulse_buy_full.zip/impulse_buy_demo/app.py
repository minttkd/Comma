from flask import Flask, request, jsonify, render_template
import json
import os

app = Flask(__name__)

DATA_PATH = os.path.join(os.path.dirname(__file__), "data", "budget.json")
LINKED_PATH = os.path.join(os.path.dirname(__file__), "data", "linked_accounts.json")

# 남은 여유가 수입의 이 비율 밑으로 떨어지면 "주의"로 표시한다.
WARNING_RATIO = 0.15


def load_budget():
    with open(DATA_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


def save_budget(budget):
    with open(DATA_PATH, "w", encoding="utf-8") as f:
        json.dump(budget, f, ensure_ascii=False, indent=2)


def load_linked_accounts():
    """실제 서비스라면 오픈뱅킹/카드사 API로 정기결제 내역을 가져오는 부분.
    이번 학기 프로토타입에서는 가상 계좌 데이터(JSON)로 시뮬레이션한다."""
    with open(LINKED_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


def summarize(budget):
    """수입 - 고정지출 합 - 이미 쓴 금액 = 남은 여유. 데이터 흐름의 핵심 계산."""
    fixed_total = sum(item["amount"] for item in budget["fixed_expenses"])
    spent_total = sum(item["amount"] for item in budget["purchases"])
    remaining = budget["income"] - fixed_total - spent_total
    return {
        "fixed_total": fixed_total,
        "spent_total": spent_total,
        "remaining": remaining,
    }


def judge(remaining_before, amount, income):
    """구매하려는 금액을 넣었을 때 신호등 상태를 판단한다."""
    remaining_after = remaining_before - amount
    buffer = income * WARNING_RATIO

    if remaining_after < 0:
        status = "danger"
        message = "이번 달 남은 여유를 넘어서는 지출이에요."
    elif remaining_after < buffer:
        status = "warning"
        message = "살 수는 있지만, 이번 달 여유가 많이 줄어들어요."
    else:
        status = "safe"
        message = "이번 달 여유 안에서 괜찮은 소비예요."

    return {
        "status": status,
        "message": message,
        "remaining_before": remaining_before,
        "remaining_after": remaining_after,
    }


@app.after_request
def add_cors_headers(response):
    """확장 프로그램이 다른 사이트(content script)에서 이 API를 호출할 수 있도록 허용한다."""
    response.headers["Access-Control-Allow-Origin"] = "*"
    response.headers["Access-Control-Allow-Headers"] = "Content-Type"
    response.headers["Access-Control-Allow-Methods"] = "GET,POST,OPTIONS"
    return response


@app.route("/api/<path:_subpath>", methods=["OPTIONS"])
def api_preflight(_subpath):
    """CORS 프리플라이트(OPTIONS) 요청에 빈 200 응답을 준다."""
    return "", 200


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/mock-shop")
def mock_shop():
    """'다른 앱'을 흉내낸 가짜 쇼핑몰 상품 페이지.
    실제로는 다른 회사 앱의 결제 버튼을 우리가 가로챌 수 없으므로,
    이번 프로토타입에서는 우리가 만든 가짜 쇼핑 페이지에서 그 상황을 재현한다."""
    return render_template("mock_shop.html")


@app.route("/api/linked-subscriptions", methods=["GET"])
def get_linked_subscriptions():
    """계좌/카드 연동으로 정기결제 내역을 자동으로 불러오는 것을 시뮬레이션한다."""
    return jsonify(load_linked_accounts())


@app.route("/api/budget", methods=["GET"])
def get_budget():
    budget = load_budget()
    return jsonify({**budget, "summary": summarize(budget)})


@app.route("/api/setup", methods=["POST"])
def setup_budget():
    """초기 설정: 수입과 고정지출 목록을 등록/수정한다."""
    data = request.get_json()
    budget = load_budget()

    try:
        income = int(data.get("income", 0))
    except (TypeError, ValueError):
        return jsonify({"error": "수입은 숫자로 입력해주세요."}), 400

    fixed_expenses = data.get("fixed_expenses", [])
    cleaned = []
    for item in fixed_expenses:
        name = (item.get("name") or "").strip()
        try:
            amount = int(item.get("amount", 0))
        except (TypeError, ValueError):
            amount = 0
        # source: "linked"(연동으로 자동 추가됨) 또는 "manual"(직접 입력)
        source = item.get("source", "manual")
        if name and amount > 0:
            cleaned.append({"name": name, "amount": amount, "source": source})

    budget["income"] = income
    budget["fixed_expenses"] = cleaned
    save_budget(budget)

    return jsonify({**budget, "summary": summarize(budget)})


@app.route("/api/check", methods=["POST"])
def check_purchase():
    """구매를 확정하기 전, 지금 사도 되는지만 판단해서 알려준다 (저장하지 않음)."""
    data = request.get_json()
    try:
        amount = int(data.get("amount", 0))
    except (TypeError, ValueError):
        return jsonify({"error": "금액은 숫자로 입력해주세요."}), 400

    budget = load_budget()
    remaining = summarize(budget)["remaining"]
    result = judge(remaining, amount, budget["income"])
    return jsonify(result)


@app.route("/api/check-simple", methods=["GET"])
def check_purchase_simple():
    """Tasker처럼 JSON 바디를 만들기 번거로운 노코드 자동화 도구를 위한 버전.
    쿼리 파라미터(?amount=30000)만으로 신호등 판단 결과를 돌려준다."""
    try:
        amount = int(request.args.get("amount", 0))
    except (TypeError, ValueError):
        return jsonify({"error": "금액은 숫자로 입력해주세요."}), 400

    budget = load_budget()
    remaining = summarize(budget)["remaining"]
    result = judge(remaining, amount, budget["income"])
    return jsonify(result)


@app.route("/api/purchases", methods=["POST"])
def add_purchase():
    """실제로 구매를 확정해서 기록에 남긴다."""
    data = request.get_json()
    name = (data.get("name") or "").strip()
    try:
        amount = int(data.get("amount", 0))
    except (TypeError, ValueError):
        return jsonify({"error": "금액은 숫자로 입력해주세요."}), 400

    if not name or amount <= 0:
        return jsonify({"error": "이름과 금액을 올바르게 입력해주세요."}), 400

    budget = load_budget()
    budget["purchases"].append({"name": name, "amount": amount, "date": "직접입력"})
    save_budget(budget)

    return jsonify({**budget, "summary": summarize(budget)}), 201


if __name__ == "__main__":
    app.run(debug=True)
